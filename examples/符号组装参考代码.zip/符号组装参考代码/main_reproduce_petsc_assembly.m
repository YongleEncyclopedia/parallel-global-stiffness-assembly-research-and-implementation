% MAIN_REPRODUCE_PETSC_ASSEMBLY
%
% 【工程目标】
% 用 MATLAB 在单机上原型复现 PETSc 非结构网格有限元刚度矩阵组装的核心思想。
%
% 【复现的三个 PETSc 核心特征】
%   1. section + closure → cellDofs（不手写 elem2dof 表）
%   2. 两阶段组装：符号阶段（拓扑/DOF 模式）→ 数值阶段（插入值）
%   3. 块插入：K(cellDofs, cellDofs) += Ke
%
% 【运行方式】
%   将工作目录切换到本文件所在的文件夹，在命令窗口输入：
%       main_reproduce_petsc_assembly
%   或直接按 F5 运行。所有辅助 .m 文件必须在同一目录下。

clear; clc; close all;

fprintf('================================================================\n');
fprintf('  PETSc 风格非结构网格组装原型\n');
fprintf('================================================================\n\n');

% =========================================================================
% 第一步：生成演示网格
% =========================================================================
fprintf('--- 第一步：生成网格 ---\n');
mesh = create_demo_mesh();

% =========================================================================
% 第二步：构建网格拓扑
%   提取唯一边，为顶点/边/单元分配连续不重叠的全局点编号区间。
% =========================================================================
fprintf('\n--- 第二步：构建网格拓扑 ---\n');
topo = build_mesh_topology(mesh);

% =========================================================================
% 第三步：定义离散化参数
%   声明每类拓扑点上挂载的自由度数量。
% =========================================================================
fprintf('\n--- 第三步：定义离散化参数 ---\n');
disc = create_discretization();

% =========================================================================
% 第四步：构建 Section（类比 PetscSection）
%   为每个拓扑点计算 (ndof, globalOffset) 映射。
% =========================================================================
fprintf('\n--- 第四步：构建 Section ---\n');
section = build_section(topo, disc);
fprintf('    全局自由度总数 section.totalDofs = %d\n', section.totalDofs);

% -------------------------------------------------------------------------
% 打印前几个点的 section 信息，直观展示 section 的内容
% -------------------------------------------------------------------------
fprintf('\n    各点 Section 信息（部分）：\n');
fprintf('    %6s  %8s  %6s  %14s\n', '点编号', '层类型', 'ndof', 'offset(0-based)');
for p = [1, 2, topo.pEdgeStart, topo.pEdgeStart+1, topo.pCellStart, topo.pCellStart+1]
    if p > topo.nPoints, continue; end
    if     p <= topo.pVertexEnd,  stratum = '顶点';
    elseif p <= topo.pEdgeEnd,    stratum = '边';
    else,                         stratum = '单元';
    end
    fprintf('    %6d  %8s  %6d  %14d\n', p, stratum, section.ndof(p), section.offset(p));
end

% =========================================================================
% 第五步：符号组装阶段（Symbolic Assembly）
%   纯拓扑 + DOF 簿记，不计算任何 Ke。
%   对应 PETSc 的 DMPlexPreallocateOperator。
% =========================================================================
fprintf('\n--- 第五步：符号组装阶段 ---\n');
symData = build_symbolic_pattern(topo, section);

% -------------------------------------------------------------------------
% 展示前 3 个单元的 closure → cellDofs 过程，直观验证逻辑链
% -------------------------------------------------------------------------
nInspect = min(3, topo.nCell);
fprintf('\n    前 %d 个单元的 Closure + cellDofs 详情：\n', nInspect);

for c = 1:nInspect
    cPoints = symData.closureCache{c};
    cDofs   = symData.cellDofsCache{c};

    fprintf('\n    单元 %d\n', c);
    fprintf('      闭包点集（共 %d 个点）：\n', length(cPoints));
    for k = 1:length(cPoints)
        p = cPoints(k);
        if     p <= topo.pVertexEnd,  stratum = '顶点';
        elseif p <= topo.pEdgeEnd,    stratum = '边';
        else,                         stratum = '单元';
        end
        fprintf('        点编号=%3d  %-4s  ndof=%d  offset=%d\n', ...
                p, stratum, section.ndof(p), section.offset(p));
    end
    fprintf('      cellDofs（共 %d 个）：[', length(cDofs));
    fprintf(' %d', cDofs);
    fprintf(' ]\n');
end

fprintf('\n    nnzEstimate（符号阶段估计非零数）= %d\n', symData.nnzEstimate);
fprintf('    每行非零数：min=%d  max=%d  均值=%.1f\n', ...
        min(symData.nnzPerRow), max(symData.nnzPerRow), mean(symData.nnzPerRow));

% =========================================================================
% 第六步：分配全局稀疏矩阵（类比 MatCreateAIJ + MatSetPreallocation）
% =========================================================================
fprintf('\n--- 第六步：分配全局稀疏矩阵 ---\n');
K_zero = allocate_global_matrix(symData);

% =========================================================================
% 第七步：设置材料参数（钢，平面应力）
% =========================================================================
matParams.E         = 210e9;   % 弹性模量，Pa（钢）
matParams.nu        = 0.3;     % 泊松比
matParams.thickness = 0.01;    % 厚度，m（平面应力）
matParams.planetype = 'stress';

% =========================================================================
% 第八步：数值组装阶段（Numeric Assembly），mode='both'
%   - 块插入路径（PETSc 风格，主路径）：K(cellDofs,cellDofs) += Ke
%   - 逐项插入路径（验证用）：双重循环逐项插入
%   两种路径均从 symData.cellDofsCache 读取 cellDofs，不重新计算。
% =========================================================================
fprintf('\n--- 第八步：数值组装阶段（mode=''both''）---\n');
[K_block, K_entry] = assemble_numeric(K_zero, mesh, topo, section, ...
                                      symData, matParams, 'both');

% =========================================================================
% 第九步：一致性验证
% =========================================================================
fprintf('\n--- 第九步：一致性验证 ---\n');
result = check_assembly_consistency(K_block, K_entry);

% =========================================================================
% 第十步：汇总统计输出
% =========================================================================
N = symData.totalDofs;
fprintf('================================================================\n');
fprintf('  最终组装统计\n');
fprintf('================================================================\n');
fprintf('  全局自由度数      N = %d\n',   N);
fprintf('  符号阶段 nnz 估计 = %d\n',     symData.nnzEstimate);
fprintf('  nnz(K_block)      = %d\n',     nnz(K_block));
fprintf('  nnz(K_entry)      = %d\n',     nnz(K_entry));
fprintf('  ||K_block-K_entry||_F = %.3e\n', result.diffNorm);
fprintf('  相对差异              = %.3e\n', result.relDiff);
fprintf('  对称误差（块插入）    = %.3e\n', result.symErrBlock);
fprintf('  对称误差（逐项插入）  = %.3e\n', result.symErrEntry);
fprintf('================================================================\n\n');

% =========================================================================
% 第十一步：可视化
% =========================================================================
fprintf('--- 第十一步：可视化 ---\n');

% 图1：K_block 的稀疏结构
figure('Name', 'K_block 稀疏结构', 'NumberTitle', 'off');
spy(K_block, 6);
title(sprintf('spy(K\\_block)   N=%d   nnz=%d   CST 平面应力', N, nnz(K_block)));
xlabel('DOF 列下标');
ylabel('DOF 行下标');

% 图2：演示网格（带节点编号）
figure('Name', '演示网格', 'NumberTitle', 'off');
trimesh(mesh.cells, mesh.nodes(:,1), mesh.nodes(:,2), ...
        zeros(mesh.nVertex,1), ...
        'EdgeColor', 'k', 'FaceColor', 'none', 'LineWidth', 1.2);
hold on;
plot(mesh.nodes(:,1), mesh.nodes(:,2), 'ro', 'MarkerSize', 6, ...
     'MarkerFaceColor', 'r');
for i = 1:mesh.nVertex
    text(mesh.nodes(i,1), mesh.nodes(i,2), sprintf('  v%d', i), ...
         'FontSize', 8, 'Color', 'b');
end
axis equal; axis tight; axis off;
title(sprintf('演示网格：%d 个顶点，%d 个三角形', mesh.nVertex, mesh.nCell));

fprintf('运行完毕。\n');
