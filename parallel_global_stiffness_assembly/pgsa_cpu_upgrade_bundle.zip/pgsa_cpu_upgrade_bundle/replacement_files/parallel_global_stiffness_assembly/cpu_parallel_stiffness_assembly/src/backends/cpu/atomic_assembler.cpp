#include "backends/cpu/atomic_assembler.h"

#include <chrono>
#include <vector>

namespace fem::cpu {
namespace {
double ms_since(const std::chrono::steady_clock::time_point t0,
                const std::chrono::steady_clock::time_point t1) {
  return std::chrono::duration<double, std::milli>(t1 - t0).count();
}
} // namespace

AtomicAssembler::AtomicAssembler(AssemblyOptions options) : CpuAssemblerBase(options) {}

void AtomicAssembler::assemble() {
  ensure_ready();
  reset_result();

  const auto t0 = std::chrono::steady_clock::now();
  const Size ne = mesh_->num_elements();
  const int nth = threads();
#ifdef _OPENMP
#pragma omp parallel num_threads(nth)
#endif
  {
    std::vector<Real> ke;
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
    for (std::int64_t ee = 0; ee < static_cast<std::int64_t>(ne); ++ee) {
      const Size e = static_cast<Size>(ee);
      compute_element_matrix(*mesh_, e, options_, ke);
      const int edofs = plan_->element_dof_count(e);
      const Index* scatter = plan_->element_scatter_ptr(e);
      for (int i = 0; i < edofs; ++i) {
        for (int j = 0; j < edofs; ++j) {
          const Size p = static_cast<Size>(scatter[i * edofs + j]);
          const Real v = ke[static_cast<Size>(i) * edofs + j];
#ifdef _OPENMP
#pragma omp atomic update
#endif
          result_.values[p] += v;
        }
      }
    }
  }
  const auto t1 = std::chrono::steady_clock::now();
  stats_.phase_times_ms["numeric"] = ms_since(t0, t1);
  stats_.assembly_time_ms = stats_.phase_times_ms["numeric"];
  stats_.total_time_ms = stats_.preprocess_time_ms + stats_.assembly_time_ms;
  stats_.diagnostics = "OpenMP atomic AddTo over precomputed CSR scatter addresses";
}

} // namespace fem::cpu
