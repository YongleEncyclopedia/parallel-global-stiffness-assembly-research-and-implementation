# CPU 主线交接说明

## 当前主入口

```text
parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly
```

## 已固定偏好

- 只改主入口，不再分叉第二套项目。
- 用户可见层中文化。
- GPU 历史内容隔离保留到 `legacy_gpu/`。
- CSV 字段继续保持英文，避免解析逻辑脆化。

## 关键文件

- `apps/benchmark/main.cpp`：benchmark CLI、CSV/JSON/Markdown 输出、状态管理。
- `include/assembly/assembler_interface.h`：装配器接口与 `AssemblyStats`。
- `scripts/run_cpu_experiments.py`：实验调度。
- `scripts/plot_cpu_results.py`：CPU 专用绘图和中文摘要。
- `scripts/archive_gpu_legacy.py`：GPU 历史文件归档。
- `docs/cpu/algorithm_overview.md`：算法机制和研究依据。

## 下一步建议

1. 在各 CPU assembler 中填充 `AssemblyStats::phase_times_ms`，让子阶段拆分从 schema 预留升级为完整实测。
2. 给 `--json` schema 增加固定版本号，方便后续兼容。
3. 增加一组极小网格 golden CSV/JSON，放入测试目录做 CLI 回归。
4. 针对 `row_owner` 增加行 nnz 分布摘要，解释负载均衡问题。
