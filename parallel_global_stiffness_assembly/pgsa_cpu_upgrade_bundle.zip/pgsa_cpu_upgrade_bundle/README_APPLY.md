# CPU-only benchmark upgrade 补丁包应用说明

这个补丁包是为仓库：

```text
https://github.com/YongleEncyclopedia/parallel-global-stiffness-assembly-research-and-implementation
```

准备的主入口原位升级。它不创建第二套项目，所有替换/新增文件都放在 `replacement_files/` 中。

## 应用变更

```bash
cd /path/to/parallel-global-stiffness-assembly-research-and-implementation
unzip /path/to/pgsa_cpu_upgrade_bundle.zip -d /tmp/pgsa_cpu_upgrade_bundle
/tmp/pgsa_cpu_upgrade_bundle/pgsa_cpu_upgrade_bundle/APPLY_CHANGES.sh "$PWD"
```

或者手动复制：

```bash
rsync -a /tmp/pgsa_cpu_upgrade_bundle/pgsa_cpu_upgrade_bundle/replacement_files/ ./
cd parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly
python3 scripts/archive_gpu_legacy.py --project .
```

## 验证命令

```bash
cd parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly
cmake -S . -B build/cpu-release -DCMAKE_BUILD_TYPE=Release -DPGSA_ENABLE_OPENMP=ON
cmake --build build/cpu-release --parallel
ctest --test-dir build/cpu-release --output-on-failure

./build/cpu-release/bin/benchmark_assembly \
  --mesh cube --element tet4 --nx 3 --ny 3 --nz 3 \
  --kernel simplified \
  --algo serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner \
  --threads-range 1:4 \
  --warmup 1 --repeat 2 --check \
  --case-name smoke_cube \
  --csv results/smoke_cube.csv \
  --json results/smoke_cube.json \
  --summary-md results/smoke_cube.md \
  --emit-skip-records

python3 scripts/plot_cpu_results.py results/smoke_cube.csv --out-dir results/smoke_figures
```

## 创建分支和 PR

```bash
git checkout -b cpu-only-benchmark-upgrade
git add README.md parallel_global_stiffness_assembly
git commit -m "Upgrade CPU-only benchmark workflow"
git push -u origin cpu-only-benchmark-upgrade
```

PR 标题和正文见本补丁包的 `PR_TITLE.txt` 与 `PR_BODY.md`。

## 本地检查结果

由于执行环境没有挂载原仓库，且 GitHub DNS/认证不可用，C++ 目标没有在此处完成实际编译。已完成的本地检查：

```bash
python3 -m py_compile scripts/plot_cpu_results.py
python3 -m py_compile scripts/run_cpu_experiments.py
python3 -m py_compile scripts/archive_gpu_legacy.py
```

C++ 变更为完整替换文件，应用后应按上面的 CMake/CTest 命令验证。
