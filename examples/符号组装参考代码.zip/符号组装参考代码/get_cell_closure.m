function closurePoints = get_cell_closure(cellIdx, topo)
% GET_CELL_CLOSURE  返回一个三角形单元的拓扑闭包中所有点的编号。
%
% 【对应 PETSc 概念】
% 类比于 PETSc 中的 DMPlexGetClosure()。
%
% 在 Hasse 图中，一个三角形的拓扑闭包定义为：
%   { 单元本身 } ∪ { 3 条边 } ∪ { 3 个顶点 }
%
% 点编号使用由 build_mesh_topology 建立的全局 PETSc 风格编号：
%   顶点 : 1 .. nV
%   边   : nV+1 .. nV+nE
%   单元 : nV+nE+1 .. nV+nE+nC
%
% 注意：仅 section.ndof > 0 的点才会贡献实际自由度，
%       但闭包中始终返回所有 7 个点，以保持与 PETSc 的概念一致。
%
% 输入：
%   cellIdx        - 单元局部编号（1 .. nCell）
%   topo           - 网格拓扑结构体
%
% 输出：
%   closurePoints  - (7 x 1) 全局点编号列向量
%                   顺序：[单元点; 边点1; 边点2; 边点3; 顶点点1; 顶点点2; 顶点点3]
%                   （遵循 PETSc 惯例：先单元，再边，再顶点）

% 单元点编号 = 单元区间起点 + 局部单元编号 - 1
cellPoint    = topo.pCellStart + cellIdx - 1;        % 标量

% 从拓扑表中读取该单元对应的边点编号（列向量，3x1）
edgePoints   = topo.cellEdgePoints(cellIdx,   :)';   % 3x1

% 从拓扑表中读取该单元对应的顶点点编号（列向量，3x1）
vertexPoints = topo.cellVertexPoints(cellIdx, :)';   % 3x1

% 拼接为 7x1 的闭包点集
closurePoints = [cellPoint; edgePoints; vertexPoints];
end
