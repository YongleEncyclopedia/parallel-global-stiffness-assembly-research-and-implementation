function [K_block, K_entry] = assemble_numeric(K_preallocated, mesh, topo, ...
                                               section, symData, matParams, mode)
% ASSEMBLE_NUMERIC  数值组装阶段（Numeric Assembly Phase）。
%
% 【阶段定位】
% 本函数是两阶段组装流程的第二阶段，专注于：
%   1. 计算每个单元的刚度矩阵 Ke
%   2. 利用符号阶段缓存的 cellDofs，将 Ke 插入全局矩阵 K
%
% 【关键约束】
% 本阶段 不重新计算 cellDofs，直接从 symData.cellDofsCache{c} 读取。
% 这与 PETSc 的行为一致：符号阶段已完成所有拓扑/DOF 簿记工作，
% 数值阶段只负责计算和插值，无需再走 closure/section 逻辑链。
%
% 【两种插入模式】
%   'block'（默认，PETSc 风格）：
%       K(cellDofs, cellDofs) += Ke
%       每个单元一次块索引操作完成插入。
%
%   'entry'（逐项插入，参考/验证用）：
%       双重循环逐项插入 Ke(i,j)，与教材写法等价。
%
%   'both'：同时执行两种模式，用于一致性对比。
%
% 输入：
%   K_preallocated - 已预分配的 N×N 稀疏矩阵（来自 allocate_global_matrix）
%   mesh           - 网格结构体
%   topo           - 拓扑结构体
%   section        - section 结构体（本阶段未直接使用，保留接口完整性）
%   symData        - 符号阶段数据，核心是 .cellDofsCache
%   matParams      - 材料参数结构体，包含：
%                      .E          弹性模量
%                      .nu         泊松比
%                      .thickness  厚度（平面应力）
%                      .planetype  'stress' 或 'strain'
%   mode           - 'block' | 'entry' | 'both'
%
% 输出：
%   K_block  - 通过块插入组装的全局刚度矩阵
%   K_entry  - 通过逐项插入组装的全局刚度矩阵（mode='block' 时为零矩阵）

nC = topo.nCell;
N  = symData.totalDofs;

E         = matParams.E;
nu        = matParams.nu;
t         = matParams.thickness;
planetype = matParams.planetype;

% 根据模式设置执行标志
do_block = ismember(lower(mode), {'block', 'both'});
do_entry = ismember(lower(mode), {'entry', 'both'});

% 初始化输出矩阵
if do_block
    K_block = K_preallocated;   % 使用预分配的稀疏结构作为起点
else
    K_block = sparse(N, N);
end
K_entry = sparse(N, N);         % 逐项插入从零矩阵开始

% -----------------------------------------------------------------------
% 主组装循环：遍历所有单元
% -----------------------------------------------------------------------
for c = 1:nC

    % ------------------------------------------------------------------
    % (a) 计算单元刚度矩阵 Ke（数值计算）
    %     从拓扑表取顶点局部编号 → 查坐标 → 计算 Ke
    % ------------------------------------------------------------------
    vIdx    = topo.cellVertexPoints(c, :);   % 顶点点编号（1..nV，可直接索引 nodes）
    nodes_e = mesh.nodes(vIdx, :);           % 3x2 单元节点坐标
    Ke      = tri3_elasticity_stiffness(nodes_e, E, nu, t, planetype);

    % ------------------------------------------------------------------
    % (b) 从符号阶段缓存读取 cellDofs（不重新计算）
    %     对应 PETSc 中 MatSetValuesLocal 时直接使用已有的局部-全局映射
    % ------------------------------------------------------------------
    cDofs = symData.cellDofsCache{c};        % nLocalDof x 1

    % ------------------------------------------------------------------
    % (c) 块插入模式（PETSc 风格，默认路径）
    %     K(I, I) += Ke，一次操作完成整个单元贡献的插入
    % ------------------------------------------------------------------
    if do_block
        K_block(cDofs, cDofs) = K_block(cDofs, cDofs) + Ke;
    end

    % ------------------------------------------------------------------
    % (d) 逐项插入模式（参考/验证路径）
    %     与 K(i,j) += Ke(li,lj) 的教材写法等价
    % ------------------------------------------------------------------
    if do_entry
        nd = length(cDofs);
        for i = 1:nd
            for j = 1:nd
                K_entry(cDofs(i), cDofs(j)) = ...
                    K_entry(cDofs(i), cDofs(j)) + Ke(i,j);
            end
        end
    end

end  % for c

fprintf('[assemble_numeric] 模式=%s  nnz(K_block)=%d  nnz(K_entry)=%d\n', ...
        mode, nnz(K_block), nnz(K_entry));
end
