function K = allocate_global_matrix(symData)
% ALLOCATE_GLOBAL_MATRIX  根据符号阶段确定的稀疏模式，分配全局稀疏刚度矩阵。
%
% 【对应 PETSc 概念】
% 类比于 PETSc 的 MatCreateAIJ + MatSetPreallocation：
% 稀疏结构由符号阶段确定，在此预分配完整的存储空间，
% 使得数值组装阶段可以直接做索引加法，而不触发内存重分配。
%
% 所有结构非零位置的初始值均为 0，数值阶段（assemble_numeric）负责填入实际值。
%
% 输入：
%   symData  - 符号阶段输出的结构体（来自 build_symbolic_pattern）
%
% 输出：
%   K        - (N x N) 稀疏矩阵，已按结构分配，所有值初始化为 0

N    = symData.totalDofs;
iIdx = symData.iIdx;
jIdx = symData.jIdx;

% 所有位置赋 0 值；sparse() 会自动合并重复的 (i,j) 对（求和为 0）
vals = zeros(size(iIdx));

K = sparse(iIdx, jIdx, vals, N, N);

fprintf('[allocate_global_matrix] 矩阵规模=%dx%d  结构非零数=%d\n', ...
        N, N, nnz(K));
end
