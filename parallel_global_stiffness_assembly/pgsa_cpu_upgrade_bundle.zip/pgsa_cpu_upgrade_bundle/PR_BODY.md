## 概要

本 PR 在现有主入口 `parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly` 原位升级 CPU benchmark 平台，不创建第二套项目。

主要改动：

- 将主 README、CPU README、CLI help、终端摘要、图表和 Markdown 摘要统一为 CPU-only / 中文优先表述。
- 新增 CPU 算法总览文档，覆盖 `serial / atomic / private_csr / coo_sort_reduce / coloring / row_owner` 的机制、同步、预处理、内存代价、适用场景和瓶颈。
- 新增 `legacy_gpu/` 说明和 `scripts/archive_gpu_legacy.py`，把 CUDA/GPU 历史内容隔离保留为归档资料。
- 扩展 benchmark CLI：`--threads-all`、`--threads-range`、`--case-name`、`--json`、`--summary-md`、`--emit-skip-records`。
- 扩展 CSV/JSON schema：case、run_count、mean/min/max/std、efficiency、preprocess_share、peak RSS、OpenMP 环境、skip_reason 和统一子阶段列。
- 统一 `PASS / FAIL / SKIP` 结果状态；内存超限和不可运行组合写入结构化原因。
- 新增 CPU 实验调度脚本，按 `results/YYYY-MM-DD/<case>/<kernel>/{csv,json,figures,summaries}` 归档。
- 重写 CPU 绘图脚本，输出中文图表、`PNG + SVG` 和中文实验摘要。

## 研究依据

文档统一引用：

- OpenMP 官方规范：线程控制、亲和、环境变量和 atomic 同步。
- CMake 官方 `FindOpenMP` 文档。
- Krysl 2024 multicore finite element assembly benchmark 论文。

## 验证

建议在本机运行：

```bash
cd parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly
cmake -S . -B build/cpu-release -DCMAKE_BUILD_TYPE=Release -DPGSA_ENABLE_OPENMP=ON
cmake --build build/cpu-release --parallel
ctest --test-dir build/cpu-release --output-on-failure

./build/cpu-release/bin/benchmark_assembly \
  --mesh cube --element tet4 --nx 3 --ny 3 --nz 3 \
  --kernel simplified \
  --algo serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner \
  --threads-range 1:4 \
  --warmup 1 --repeat 2 --check \
  --case-name smoke_cube \
  --csv results/smoke_cube.csv \
  --json results/smoke_cube.json \
  --summary-md results/smoke_cube.md \
  --emit-skip-records

python3 scripts/plot_cpu_results.py results/smoke_cube.csv --out-dir results/smoke_figures
```

## 备注

`AssemblyStats::phase_times_ms` 和输出 schema 已预留统一子阶段统计；后续可继续在各 assembler 内填充更细的实测子阶段。
