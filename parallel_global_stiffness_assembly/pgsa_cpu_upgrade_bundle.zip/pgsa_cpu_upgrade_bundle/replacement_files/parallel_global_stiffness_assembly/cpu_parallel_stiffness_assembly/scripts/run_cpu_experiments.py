#!/usr/bin/env python3
"""CPU 实验调度脚本。

按统一目录结构输出到：results/YYYY-MM-DD/<case>/<kernel>/{csv,json,figures,summaries}
默认不后台执行；每个 benchmark 命令串行运行，失败即返回非零。
"""

from __future__ import annotations

import argparse
import datetime as dt
import subprocess
import sys
from pathlib import Path


def is_lfs_pointer(path: Path) -> bool:
    if not path.exists():
        return False
    data = path.read_bytes()[:256]
    return b"version https://git-lfs.github.com/spec/v1" in data


def run(cmd: list[str], cwd: Path) -> None:
    print("\n$ " + " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def run_benchmark(project: Path,
                  binary: Path,
                  out_root: Path,
                  case: str,
                  kernel: str,
                  mesh_args: list[str],
                  algorithms: str,
                  threads: str,
                  warmup: int,
                  repeat: int,
                  max_memory_gb: float,
                  check: bool) -> None:
    case_dir = out_root / case / kernel
    csv_dir = case_dir / "csv"
    json_dir = case_dir / "json"
    fig_dir = case_dir / "figures"
    summary_dir = case_dir / "summaries"
    for d in (csv_dir, json_dir, fig_dir, summary_dir):
        d.mkdir(parents=True, exist_ok=True)

    csv = csv_dir / f"{case}_{kernel}.csv"
    js = json_dir / f"{case}_{kernel}.json"
    md = summary_dir / f"{case}_{kernel}.md"
    cmd = [
        str(binary),
        *mesh_args,
        "--case-name", case,
        "--kernel", kernel,
        "--algo", algorithms,
        "--threads-list", threads,
        "--warmup", str(warmup),
        "--repeat", str(repeat),
        "--max-memory-gb", str(max_memory_gb),
        "--csv", str(csv),
        "--json", str(js),
        "--summary-md", str(md),
        "--emit-skip-records",
    ]
    if check:
        cmd.append("--check")
    run(cmd, project)
    run([sys.executable, "scripts/plot_cpu_results.py", str(csv), "--out-dir", str(fig_dir)], project)


def main() -> None:
    parser = argparse.ArgumentParser(description="运行 CPU strong-scaling 实验并归档结果")
    parser.add_argument("--project", type=Path, default=Path.cwd(), help="cpu_parallel_stiffness_assembly 根目录")
    parser.add_argument("--binary", type=Path, default=None, help="benchmark_assembly 可执行文件")
    parser.add_argument("--out-root", type=Path, default=None, help="结果根目录，默认 results/YYYY-MM-DD")
    parser.add_argument("--threads-full", default="1,2,3,4,5,6,7,8,9,10,11,12,13,14")
    parser.add_argument("--threads-physics", default="1,2,4,8,14")
    parser.add_argument("--threads-coo-physics", default="1,2,4")
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--repeat", type=int, default=3)
    parser.add_argument("--max-memory-gb", type=float, default=8.0)
    parser.add_argument("--skip-windhub", action="store_true")
    parser.add_argument("--no-check", action="store_true")
    args = parser.parse_args()

    project = args.project.resolve()
    binary = args.binary or (project / "build" / "cpu-release" / "bin" / "benchmark_assembly")
    binary = binary.resolve()
    if not binary.exists():
        raise SystemExit(f"找不到 benchmark 可执行文件: {binary}")

    out_root = args.out_root or (project / "results" / dt.date.today().isoformat())
    out_root = out_root.resolve()
    check = not args.no_check

    all_algorithms = "serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner"
    non_coo_physics = "serial,atomic,private_csr,coloring,row_owner"

    run_benchmark(
        project, binary, out_root,
        case="cube_tet4",
        kernel="simplified",
        mesh_args=["--mesh", "cube", "--element", "tet4", "--nx", "8", "--ny", "8", "--nz", "8"],
        algorithms=all_algorithms,
        threads=args.threads_full,
        warmup=args.warmup,
        repeat=args.repeat,
        max_memory_gb=args.max_memory_gb,
        check=check,
    )

    if args.skip_windhub:
        return

    windhub = project / "examples" / "3d-WindTurbineHub.inp"
    if is_lfs_pointer(windhub):
        raise SystemExit("真实工程网格还是 Git LFS pointer。请先运行：git lfs install && git lfs pull")
    if not windhub.exists():
        raise SystemExit(f"找不到真实工程网格: {windhub}")

    run_benchmark(
        project, binary, out_root,
        case="windhub",
        kernel="simplified",
        mesh_args=["--mesh", "inp", "--inp", str(windhub)],
        algorithms=all_algorithms,
        threads=args.threads_full,
        warmup=args.warmup,
        repeat=args.repeat,
        max_memory_gb=args.max_memory_gb,
        check=check,
    )
    run_benchmark(
        project, binary, out_root,
        case="windhub_physics_noncoo",
        kernel="physics_tet4",
        mesh_args=["--mesh", "inp", "--inp", str(windhub)],
        algorithms=non_coo_physics,
        threads=args.threads_physics,
        warmup=args.warmup,
        repeat=args.repeat,
        max_memory_gb=args.max_memory_gb,
        check=check,
    )
    run_benchmark(
        project, binary, out_root,
        case="windhub_physics_coo",
        kernel="physics_tet4",
        mesh_args=["--mesh", "inp", "--inp", str(windhub)],
        algorithms="coo_sort_reduce",
        threads=args.threads_coo_physics,
        warmup=args.warmup,
        repeat=args.repeat,
        max_memory_gb=args.max_memory_gb,
        check=check,
    )
    print(f"\n全部实验完成，结果根目录: {out_root}")


if __name__ == "__main__":
    main()
