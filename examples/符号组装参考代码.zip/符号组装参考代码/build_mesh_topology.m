function topo = build_mesh_topology(mesh)
% BUILD_MESH_TOPOLOGY  提取网格边，并按 PETSc DMPlex 风格为所有拓扑实体分配全局点编号。
%
% 【核心思想】
% 在 PETSc DMPlex 中，单元、边、顶点都被统一抽象为"点（point）"，
% 用一个连续的整数区间来标识，按维度（stratum）分段存放：
%
%   stratum 0（dim=2）: 单元   — 点编号区间 [nV+nE+1, nV+nE+nC]
%   stratum 1（dim=1）: 边     — 点编号区间 [nV+1,    nV+nE   ]
%   stratum 2（dim=0）: 顶点   — 点编号区间 [1,       nV      ]
%
% 本工程将顶点放在最前面，使顶点点编号与顶点局部编号一致，
% 便于直接索引 mesh.nodes，无需额外偏移。
%
% 三个区间保证 连续、不重叠，由函数末尾的断言验证。
%
% 输入：
%   mesh  - create_demo_mesh 返回的结构体
%
% 输出：
%   topo.nVertex, .nEdge, .nCell, .nPoints
%   topo.pVertexStart, .pVertexEnd   — 顶点点编号区间（含端点）
%   topo.pEdgeStart,   .pEdgeEnd     — 边点编号区间（含端点）
%   topo.pCellStart,   .pCellEnd     — 单元点编号区间（含端点）
%   topo.cellVertexPoints  (nC x 3)  — 每个单元的三个顶点点编号
%   topo.cellEdgePoints    (nC x 3)  — 每个单元的三条边点编号
%   topo.edgeVertexPoints  (nE x 2)  — 每条边的两个顶点点编号

nV    = mesh.nVertex;
nC    = mesh.nCell;
cells = mesh.cells;   % nC x 3，每个元素取值范围 1..nV

% ======================================================================
% 第一步：提取唯一边
% ======================================================================
% 每个三角形贡献 3 条边，用排序后的顶点对表示（保证唯一性）：
%   边0: sort([v1, v2])
%   边1: sort([v2, v3])
%   边2: sort([v1, v3])
%
% 收集全部 3*nC 条候选边后，用 unique() 去重得到唯一边集合。
% 返回的逆向索引 ic 满足：rawEdges(k,:) == uniqueEdges(ic(k),:)
% -----------------------------------------------------------------------
rawEdges = zeros(3*nC, 2);
for c = 1:nC
    v = cells(c, :);                                   % [v1, v2, v3]
    rawEdges(3*(c-1)+1, :) = sort([v(1), v(2)]);
    rawEdges(3*(c-1)+2, :) = sort([v(2), v(3)]);
    rawEdges(3*(c-1)+3, :) = sort([v(1), v(3)]);
end

% unique(...,'rows','sorted') 保证边的规范排序，ic 长度为 3*nC
[uniqueEdges, ~, ic] = unique(rawEdges, 'rows', 'sorted');
nE = size(uniqueEdges, 1);

% 将 ic 重整为 (nC x 3)：第 c 行是单元 c 的三条边的局部边编号
% 注意：reshape(ic,3,nC)' 与上面逐行填入的顺序一致（cell-major）
cellEdgeLocalIdx = reshape(ic, 3, nC)';    % nC x 3，取值 1..nE

% ======================================================================
% 第二步：分配连续不重叠的点编号区间
% ======================================================================
topo.nVertex = nV;
topo.nEdge   = nE;
topo.nCell   = nC;
topo.nPoints = nV + nE + nC;

topo.pVertexStart = 1;
topo.pVertexEnd   = nV;
topo.pEdgeStart   = nV + 1;
topo.pEdgeEnd     = nV + nE;
topo.pCellStart   = nV + nE + 1;
topo.pCellEnd     = nV + nE + nC;

% ======================================================================
% 第三步：建立连接关系表（用全局点编号表示）
% ======================================================================

% 单元 -> 顶点点编号（顶点点编号 == 顶点局部编号，无需偏移）
topo.cellVertexPoints = cells;                      % nC x 3，取值 1..nV

% 单元 -> 边点编号（局部边编号 + nV 偏移 = 边点编号）
topo.cellEdgePoints   = cellEdgeLocalIdx + nV;      % nC x 3，取值 nV+1..nV+nE

% 边 -> 顶点点编号
topo.edgeVertexPoints = uniqueEdges;                % nE x 2，取值 1..nV

% ======================================================================
% 第四步：区间完整性断言（捕捉编程错误）
% ======================================================================
assert(min(topo.cellEdgePoints(:))   == nV + 1,  ...
    'build_mesh_topology: cellEdgePoints 下界错误');
assert(max(topo.cellEdgePoints(:))   == nV + nE, ...
    'build_mesh_topology: cellEdgePoints 上界错误');
assert(min(topo.cellVertexPoints(:)) == 1,        ...
    'build_mesh_topology: cellVertexPoints 下界错误');
assert(max(topo.cellVertexPoints(:)) == nV,       ...
    'build_mesh_topology: cellVertexPoints 上界错误');

% 验证三个区间连续且不重叠
assert(topo.pVertexEnd + 1 == topo.pEdgeStart,  '边区间不连续');
assert(topo.pEdgeEnd   + 1 == topo.pCellStart,  '单元区间不连续');
assert(topo.pCellEnd       == topo.nPoints,     'nPoints 不一致');

fprintf('[build_mesh_topology] nVertex=%d  nEdge=%d  nCell=%d  nPoints=%d\n', ...
        nV, nE, nC, topo.nPoints);
fprintf('[build_mesh_topology] 顶点区间:[%d,%d]  边区间:[%d,%d]  单元区间:[%d,%d]\n', ...
        topo.pVertexStart, topo.pVertexEnd, ...
        topo.pEdgeStart,   topo.pEdgeEnd,   ...
        topo.pCellStart,   topo.pCellEnd);
end
