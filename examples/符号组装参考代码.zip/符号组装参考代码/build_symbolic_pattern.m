function symData = build_symbolic_pattern(topo, section)
% BUILD_SYMBOLIC_PATTERN  符号组装阶段（Symbolic Assembly Phase）。
%
% =========================================================================
% 【阶段定位与 PETSc 类比】
% =========================================================================
% PETSc 采用两遍组装策略，本函数对应第一遍（符号遍）：
%
%   第一遍（本函数）— 符号阶段：
%     只走网格拓扑，确定全局矩阵 K 中哪些 (i,j) 位置是结构非零。
%     缓存每个单元的 cellDofs，供数值阶段直接复用。
%     【注意】本函数中绝对不计算单元刚度矩阵 Ke，只做拓扑/DOF 簿记。
%
%   第二遍（assemble_numeric）— 数值阶段：
%     计算每个单元的 Ke，并利用已缓存的 cellDofs 将值插入 K。
%     稀疏结构已固定，不发生模式变化。
%
% 对应 PETSc 操作：DMPlexPreallocateOperator（符号）/ MatSetValues（数值）
%
% =========================================================================
% 【每个单元的逻辑链】
% =========================================================================
%
%   单元 c
%    └─► get_cell_closure(c, topo)
%         └─► closurePoints [7x1: 单元点; 3条边点; 3个顶点点]
%              └─► build_cell_dofs(c, topo, section)
%                   └─► 遍历 closurePoints 中每个点 p：
%                         offset = section.offset(p)
%                         ndof   = section.ndof(p)
%                         收集下标 offset+1 .. offset+ndof
%                          └─► cellDofs [nLocalDof x 1]
%                               ├─► 缓存至 cellDofsCache{c}
%                               ├─► 闭包缓存至 closureCache{c}
%                               └─► cellDofs 的外积 → (i,j) 稀疏模式
%
% =========================================================================
% 输入 / 输出
% =========================================================================
% 输入：
%   topo     - 网格拓扑结构体（来自 build_mesh_topology）
%   section  - section 结构体（来自 build_section）
%
% 输出字段（symData）：
%
%   .cellDofsCache  {nCell x 1}  每个单元的 cellDofs 列向量缓存
%                                （1-based 全局 DOF 下标）
%
%   .closureCache   {nCell x 1}  每个单元的拓扑闭包点集缓存
%                                （全局点编号列向量）
%
%   .iIdx           (nnz x 1)   稀疏模式的行下标（含重复，去重前）
%   .jIdx           (nnz x 1)   稀疏模式的列下标（含重复，去重前）
%
%   .adjRows        {N x 1}     adjRows{i} = 第 i 行所有结构非零列的
%                               有序唯一下标集合（邻接表表示）
%                               对应 PETSc 的 d_nnz / o_nnz 预分配信息
%
%   .nnzPerRow      (N x 1)     每行的结构非零数 = cellfun(@length, adjRows)
%
%   .nnzEstimate    标量        全局结构非零总数（去重后）
%
%   .totalDofs      标量        N = 全局自由度总数

% =========================================================================
% 实现
% =========================================================================

nC = topo.nCell;
N  = section.totalDofs;

% -----------------------------------------------------------------------
% S1 阶段：逐单元遍历
%   - 调用 get_cell_closure（纯拓扑，不碰 Ke）
%   - 调用 build_cell_dofs  （纯 DOF 簿记，不碰 Ke）
%   - 缓存结果
%   - 累积 (i,j) 下标对
% -----------------------------------------------------------------------

cellDofsCache = cell(nC, 1);
closureCache  = cell(nC, 1);

% 预分配缓冲区上界：
% CST 单元 nLocalDof=6，每个单元最多贡献 6*6=36 个 (i,j) 对。
% 乘以冗余系数以应对未来 dofsPerEdge>0 的情况。
maxLocalDof     = 6 + 3 * section.ndof(topo.pEdgeStart) ...
                    + section.ndof(topo.pCellStart);
maxPairsPerCell = (maxLocalDof + 6)^2;
maxPairs        = nC * maxPairsPerCell;

iIdx = zeros(maxPairs, 1);
jIdx = zeros(maxPairs, 1);
ptr  = 0;   % 当前缓冲区填写位置

for c = 1:nC

    % ------------------------------------------------------------------
    % S1a: 获取拓扑闭包
    %   纯拓扑操作 —— 不涉及坐标，不涉及 Ke
    % ------------------------------------------------------------------
    cPoints = get_cell_closure(c, topo);   % 三角形：7x1
    closureCache{c} = cPoints;

    % ------------------------------------------------------------------
    % S1b: 通过 section 提取 cellDofs
    %   纯 DOF 簿记 —— 查表操作，不涉及 Ke
    % ------------------------------------------------------------------
    cDofs = build_cell_dofs(c, topo, section);   % nLocalDof x 1
    cellDofsCache{c} = cDofs;

    % ------------------------------------------------------------------
    % S1c: cellDofs 的外积 → 记录 (i,j) 稀疏位置
    %   每对 (r, s) ∈ cellDofs × cellDofs 都是潜在的非零位置，
    %   重复项在 S2 阶段通过 sparse() 自动合并。
    % ------------------------------------------------------------------
    nd     = length(cDofs);
    nPairs = nd * nd;

    [II, JJ] = ndgrid(cDofs, cDofs);          % nd x nd 下标网格
    iIdx(ptr+1 : ptr+nPairs) = II(:);
    jIdx(ptr+1 : ptr+nPairs) = JJ(:);
    ptr = ptr + nPairs;

end  % for c

% 截断至实际填写长度
iIdx = iIdx(1:ptr);
jIdx = jIdx(1:ptr);

% -----------------------------------------------------------------------
% S2 阶段：构建邻接表（adjRows）
%   adjRows{i} = 第 i 行所有结构非零列的有序唯一集合。
%   这对应 PETSc 的 d_nnz（对角块非零数）/ o_nnz（非对角块非零数）
%   预分配参数，是 MatCreateAIJ + MatSetPreallocation 的依据。
% -----------------------------------------------------------------------

% 利用 sparse() 去重：重复的 (i,j) 会被求和，但这里只关心结构
patternMatrix = sparse(iIdx, jIdx, ones(size(iIdx)), N, N);

adjRows   = cell(N, 1);
nnzPerRow = zeros(N, 1);

for i = 1:N
    adjRows{i}   = find(patternMatrix(i, :));   % 有序唯一列下标
    nnzPerRow(i) = length(adjRows{i});
end

nnzEstimate = sum(nnzPerRow);   % = nnz(patternMatrix)

% -----------------------------------------------------------------------
% 打包输出
% -----------------------------------------------------------------------
symData.cellDofsCache = cellDofsCache;
symData.closureCache  = closureCache;
symData.iIdx          = iIdx;
symData.jIdx          = jIdx;
symData.adjRows       = adjRows;
symData.nnzPerRow     = nnzPerRow;
symData.nnzEstimate   = nnzEstimate;
symData.totalDofs     = N;

% -----------------------------------------------------------------------
% 诊断输出
% -----------------------------------------------------------------------
fprintf('[build_symbolic_pattern] N=%d  原始(i,j)对=%d  去重后nnz估计=%d\n', ...
        N, ptr, nnzEstimate);
fprintf('[build_symbolic_pattern] 每行非零数: min=%d  max=%d  均值=%.1f\n', ...
        min(nnzPerRow), max(nnzPerRow), mean(nnzPerRow));

end
