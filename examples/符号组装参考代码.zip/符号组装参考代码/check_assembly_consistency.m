function result = check_assembly_consistency(K_block, K_entry, tol)
% CHECK_ASSEMBLY_CONSISTENCY  验证块插入与逐项插入两种组装结果的一致性。
%
% 【验证目标】
% 对于正确的实现，以下两个条件必须同时满足：
%   1. K_block ≡ K_entry       （两种插入策略结果相同）
%   2. K ≡ K^T                 （线弹性刚度矩阵必须对称）
%
% 第 2 条源于 CST 单元刚度矩阵 Ke = B^T D B 的天然对称性。
% 对应 PETSc 的 MatIsSymmetric() 检查。
%
% 输入：
%   K_block  - 通过块插入组装的全局刚度矩阵
%   K_entry  - 通过逐项插入组装的全局刚度矩阵
%   tol      - 相对误差容差（可选，默认 1e-10）
%
% 输出字段（result）：
%   .diffNorm      - ||K_block - K_entry||_F
%   .relDiff       - diffNorm / ||K_block||_F
%   .symErrBlock   - ||K_block - K_block^T||_F / ||K_block||_F
%   .symErrEntry   - ||K_entry - K_entry^T||_F / ||K_entry||_F
%   .passConsist   - 逻辑值：两种组装结果是否在容差内一致
%   .passSymBlock  - 逻辑值：K_block 是否对称
%   .passSymEntry  - 逻辑值：K_entry 是否对称

if nargin < 3
    tol = 1e-10;
end

% -----------------------------------------------------------------------
% 1. 两种组装方式的一致性检验
% -----------------------------------------------------------------------
diffNorm = norm(K_block - K_entry, 'fro');
refNorm  = norm(K_block, 'fro');
relDiff  = diffNorm / max(refNorm, eps);

% -----------------------------------------------------------------------
% 2. 对称性检验
%    线弹性的 Ke = B^T D B 是对称正半定矩阵，
%    因此组装后的全局 K 也应严格对称（机器精度内）。
% -----------------------------------------------------------------------
symErrBlock = norm(K_block - K_block', 'fro') / max(norm(K_block, 'fro'), eps);
symErrEntry = norm(K_entry - K_entry', 'fro') / max(norm(K_entry, 'fro'), eps);

% -----------------------------------------------------------------------
% 3. 判断是否通过
% -----------------------------------------------------------------------
passConsist  = relDiff     < tol;
passSymBlock = symErrBlock < tol;
passSymEntry = symErrEntry < tol;

% -----------------------------------------------------------------------
% 4. 打印报告
% -----------------------------------------------------------------------
fprintf('\n');
fprintf('===========================================================\n');
fprintf('  组装一致性检验报告\n');
fprintf('===========================================================\n');
fprintf('  ||K_block - K_entry||_F       = %.4e\n', diffNorm);
fprintf('  相对差异（块 vs 逐项）         = %.4e   ', relDiff);
print_status(passConsist);

fprintf('  对称误差（块插入）             = %.4e   ', symErrBlock);
print_status(passSymBlock);

fprintf('  对称误差（逐项插入）           = %.4e   ', symErrEntry);
print_status(passSymEntry);
fprintf('===========================================================\n');

if passConsist && passSymBlock && passSymEntry
    fprintf('  结论：所有检验均通过（PASS）\n');
    fprintf('  块插入与逐项插入结果完全一致，矩阵对称性满足机器精度。\n');
else
    fprintf('  结论：存在检验未通过项（FAIL），请核查上述指标。\n');
end
fprintf('===========================================================\n\n');

% -----------------------------------------------------------------------
% 5. 打包输出
% -----------------------------------------------------------------------
result.diffNorm    = diffNorm;
result.relDiff     = relDiff;
result.symErrBlock = symErrBlock;
result.symErrEntry = symErrEntry;
result.passConsist  = passConsist;
result.passSymBlock = passSymBlock;
result.passSymEntry = passSymEntry;

end  % function

% -----------------------------------------------------------------------
% 内部辅助函数：打印 PASS / FAIL 标记
% -----------------------------------------------------------------------
function print_status(flag)
if flag
    fprintf('[PASS]\n');
else
    fprintf('[FAIL]\n');
end
end
