# CPU 主线需求说明

## 范围

当前主线只覆盖 CPU 多线程全局刚度矩阵装配。默认入口、默认构建、CLI、图表和摘要都围绕 CPU OpenMP benchmark 展开。

## 必须满足

1. 主入口保持 `parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly`，不新增第二套项目。
2. 用户可见层中文优先：README、CLI help、终端摘要、实验摘要、图表标题和图例使用中文；CSV 字段保持英文。
3. GPU/CUDA 历史内容迁入 `legacy_gpu/`，只作历史参考。
4. benchmark 支持 `--threads-all`、`--threads-range`、`--threads-list` 三种线程扫描方式。
5. benchmark 支持 CSV、JSON、Markdown 三类输出。
6. `PASS / FAIL / SKIP` 状态必须结构化写入结果；可跳过原因写入 `skip_reason`。
7. 真实工程网格运行前必须检查 Git LFS pointer。
8. 绘图脚本必须可从 CSV 直接生成 `PNG + SVG` 和中文摘要。

## 非目标

- 不把 CUDA/GPU 重新纳入默认构建。
- 不把 CSV schema 全部中文化。
- 不要求一次性翻译全仓库历史注释。
- 不把实验脚本设计成后台服务；所有命令显式运行、显式输出。
