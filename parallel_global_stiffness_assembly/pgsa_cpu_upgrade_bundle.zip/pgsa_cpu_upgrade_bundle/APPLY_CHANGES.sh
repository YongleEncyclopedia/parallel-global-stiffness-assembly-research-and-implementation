#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "用法: $0 /path/to/parallel-global-stiffness-assembly-research-and-implementation" >&2
  exit 2
fi

REPO_ROOT="$1"
BUNDLE_ROOT="$(cd "$(dirname "$0")" && pwd)"

if [[ ! -d "$REPO_ROOT/.git" ]]; then
  echo "目标目录不是 Git 仓库: $REPO_ROOT" >&2
  exit 2
fi

rsync -a "$BUNDLE_ROOT/replacement_files/" "$REPO_ROOT/"

CPU_DIR="$REPO_ROOT/parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly"
if [[ -f "$CPU_DIR/scripts/archive_gpu_legacy.py" ]]; then
  python3 "$CPU_DIR/scripts/archive_gpu_legacy.py" --project "$CPU_DIR"
fi

echo "变更已应用。建议接着运行："
echo "  cd '$CPU_DIR'"
echo "  cmake -S . -B build/cpu-release -DCMAKE_BUILD_TYPE=Release -DPGSA_ENABLE_OPENMP=ON"
echo "  cmake --build build/cpu-release --parallel"
echo "  ctest --test-dir build/cpu-release --output-on-failure"
