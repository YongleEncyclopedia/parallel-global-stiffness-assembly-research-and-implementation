# CPU 全局刚度矩阵装配算法总览

本文档面向读者和实验复现者，而不是只面向代码维护者。当前主入口是 `parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly`，默认研究对象为 CPU 多线程全局刚度矩阵装配；CUDA/GPU 相关内容仅保留为历史参考。

## 研究依据

- OpenMP 规范把线程控制、`proc_bind`、`places`、同步构造和 `atomic` 更新作为并行区域的重要组成部分；本项目在 benchmark 中记录 `omp_threads_effective`、`omp_proc_bind`、`omp_places`、`omp_dynamic`，用于解释同一算法在不同运行时配置下的差异。参见 OpenMP Specification 5.2 HTML：<https://www.openmp.org/spec-html/5.2/openmp.html>。
- CMake 官方 `FindOpenMP` 模块提供 `OpenMP::OpenMP_<lang>` imported target，并抽象不同编译器的 OpenMP 选项；本项目仍以 `PGSA_ENABLE_OPENMP=ON` 和 CMake `find_package(OpenMP)` 作为推荐入口。参见 CMake 文档：<https://cmake.org/cmake/help/latest/module/FindOpenMP.html>。
- Krysl 的 multicore FEM assembly 论文强调：有限元装配性能不能只看单个局部循环，还要把预处理、矩阵访问模式、同步和完整流程纳入评估；其 benchmark 覆盖多类算法并讨论多核扩展性。参见：P. Krysl, “Benchmarking multicore algorithms for finite element assembly,” *Advances in Engineering Software*, 2024, DOI: <https://doi.org/10.1016/j.advengsoft.2024.103680>。

## 数据流与统一口径

1. 网格来源：规则 `cube tet4` 或 Abaqus `.inp` 工程网格。
2. 稀疏结构：先建立全局 CSR 结构，数值装配阶段只写 `values`。
3. 参考解：`serial` 作为数值正确性基线；开启 `--check` 时输出 `rel_l2` 与 `max_abs`。
4. 计时口径：
   - `preprocess_ms`：颜色划分、行归属、私有缓冲或 COO 预备工作等一次性成本。
   - `assembly_mean/min/max/std`：数值装配重复运行统计。
   - `total_mean/min/max/std`：`preprocess + assembly` 的端到端统计。
   - `efficiency`：相对同算法 1 线程或 serial 基线的并行效率。
   - `preprocess_share`：预处理占总时间比例，用来识别“预处理主导”的算法。
5. 内存口径：`extra_memory_bytes` 记录算法声明的附加内存；`peak_rss_mb` 记录进程峰值常驻集大小，平台不支持时为 `0`。

## 算法摘要表

| 算法 | 源码落点 | 核心思路 | 同步方式 | 预处理 | 额外内存 | 更适合的场景 | 主要瓶颈 |
|---|---|---|---|---|---|---|---|
| `serial` | `src/backends/cpu/serial_assembler.cpp` | 单线程按单元逐项写入 CSR | 无 | 无 | 近似 0 | 正确性基线、小网格、回归测试 | 不使用多核 |
| `atomic` | `src/backends/cpu/atomic_assembler.cpp` | 多线程遍历单元，共享 CSR 数值数组 | 对共享条目执行 OpenMP atomic | 很少 | 近似 0 | 快速得到并行 baseline、内存紧张 | 热点自由度导致原子竞争 |
| `private_csr` | `src/backends/cpu/private_csr_assembler.cpp` | 每线程一份 CSR values，最后按 nnz 归约 | 主装配阶段无共享写冲突；归约阶段合并 | 分配并清零私有 values | `threads × nnz × sizeof(value)` | 中等网格、内存充裕、需要稳定数值写入 | 内存带宽和归约成本 |
| `coo_sort_reduce` | `src/backends/cpu/coo_sort_reduce_assembler.cpp` | 每线程生成局部 COO 三元组，合并排序后 reduce 到 CSR | 生成阶段线程局部；排序/归约集中处理 | COO 容量、全局排序准备 | 与单元贡献项数量成正比 | 不想频繁查 CSR 位置、便于研究 sort/reduce 管线 | COO 爆内存、排序成本高 |
| `coloring` | `src/backends/cpu/graph_coloring_assembler.cpp` | 单元图着色，同色单元无共享自由度冲突 | 同色并行、颜色之间串行屏障 | 贪心着色/冲突图 | 颜色和邻接结构 | 冲突密集但可被颜色分层消除的网格 | 颜色数过多导致屏障和串行比例上升 |
| `row_owner` | `src/backends/cpu/row_owner_assembler.cpp` | 按 CSR 行区间分配 owner，线程只写自己拥有的行 | owner-computes，主写入无 atomic | 行区间和贡献路由 | 贡献暂存/分区结构 | 行 nnz 分布较均衡的大网格 | 行负载不均、跨行贡献重排 |

## 各算法说明

### 1. `serial`

`serial` 是所有实验的参考实现。它按单元遍历，计算局部刚度矩阵后直接累加到全局 CSR values。它不使用 OpenMP，也不需要同步，因此计时稳定、内存开销低。所有并行算法的数值误差都应与它比较。

**建议使用**：单元数较少、需要确认 `.inp` 读入和局部 kernel 正确、或者给 speedup 计算提供基线。

### 2. `atomic`

`atomic` 保留单元并行的自然写法：不同线程同时处理不同单元，并把局部矩阵贡献累加到共享 CSR values。为了避免多个线程同时写同一个全局条目，它在共享更新位置使用 OpenMP atomic。

**优点**：实现直接、额外内存很低，适合作为第一个并行 baseline。

**代价**：如果网格中很多单元共享同一批自由度，atomic 会在热点条目上串行化；即使没有极端热点，原子写也会破坏部分缓存友好性。

**观测指标**：当 `threads` 增加但 `assembly_mean` 不再下降，且 `efficiency` 快速降低时，通常说明 atomic 竞争或内存带宽已经成为主因。

### 3. `private_csr`

`private_csr` 为每个 OpenMP 线程分配一份与全局 CSR values 同长度的私有数组。装配阶段，线程只写自己的私有 values，因此没有共享写冲突。所有线程结束后，再对每个 nnz 位置做跨线程归约。

本轮 benchmark schema 为它预留了三个子阶段：

- `alloc_zero`：分配并清零线程私有 CSR values。
- `element_assemble`：单元局部贡献写入私有 values。
- `nnz_reduce`：把所有私有 values 按 nnz 累加回全局 values。

**优点**：主装配阶段没有 atomic，数值写入路径简单。

**代价**：内存成本随 `threads × nnz` 线性增长；当 nnz 很大时，分配、清零和归约都会成为带宽型瓶颈。

**建议使用**：中等规模网格、机器内存充裕、希望观察“无冲突写入 + 归约”的上限。

### 4. `coo_sort_reduce`

`coo_sort_reduce` 不直接写 CSR values，而是先生成局部 COO 三元组 `(row, col, value)`。之后把各线程 COO 合并，按 `(row, col)` 排序，最后把同一全局条目的贡献 reduce 到 CSR。

本轮 benchmark schema 为它预留了四个子阶段：

- `local_generate`：线程局部生成 COO 三元组。
- `merge`：合并线程局部容器。
- `sort`：按 `(row, col)` 排序。
- `reduce`：相同键归并并写回 CSR。

**优点**：局部生成阶段线程独立，避免 CSR 插入位置查找和共享写冲突；算法边界清晰，适合分析 sort/reduce 管线。

**代价**：COO 数量约等于所有单元局部矩阵贡献项总数，真实工程网格和 physics kernel 下会显著放大内存占用；排序成本通常不随线程数线性下降。

**建议使用**：规则网格或小到中等工程网格；大工程网格的 physics kernel 建议先限制线程点位和内存上限。

### 5. `coloring`

`coloring` 把有写冲突的单元拆到不同颜色。每个颜色内部的单元没有共享自由度冲突，可以并行装配；颜色之间按顺序执行，从而避免 atomic。

**预处理**：建立单元冲突关系并执行贪心着色，得到颜色数与每个颜色的单元列表。

**优点**：主装配阶段可以避免共享写冲突，内存成本通常低于 `private_csr`。

**代价**：颜色数越多，颜色间屏障越多；如果颜色分布不均，部分颜色可能只含少量单元，线程利用率会下降。

**建议使用**：冲突结构能被较少颜色覆盖的网格；对真实网格需重点查看 `colors`、`preprocess_share` 和各线程效率。

### 6. `row_owner`

`row_owner` 采用 owner-computes：把 CSR 行划分给线程，线程只写自己拥有的行。对于一个单元产生的局部矩阵贡献，只有目标行 owner 负责写入对应 CSR 行。

本轮 benchmark schema 为它预留两个子阶段：

- `owner_partition`：计算行归属和必要的贡献路由。
- `numeric`：owner 线程执行数值累加。

**优点**：共享写入规则明确，避免对同一 CSR 行的写冲突；在行 nnz 分布均衡时，可获得较好的扩展性。

**代价**：真实网格常出现行 nnz 或单元贡献不均；如果 owner 分区过粗，部分线程会成为慢尾。

**建议使用**：自由度/nnz 分布相对均衡的大网格；如果 `efficiency` 偏低，应结合行 nnz 直方图继续分析负载均衡。

## Benchmark 输出如何读

- `status=PASS`：完成运行，且在 `--check` 下误差未触发失败。
- `status=FAIL`：运行完成但数值校验失败，或发生非可跳过错误。
- `status=SKIP`：内存上限、算法不适用或线程组合无意义。例如 `serial` 在 `threads>1` 下会被视作 skip，避免污染 strong-scaling 图。
- `skip_reason`：中文可读原因，便于摘要直接解释。
- `phase_*_ms`：统一子阶段列。某个算法没有填充该阶段时为 `0`。

## 实验建议

- 规则网格先使用完整线程扫：`--mesh cube --element tet4 --threads-range 1:14`。
- 真实工程网格先跑 `simplified`，确认趋势和内存，再跑 `physics_tet4`。
- `coo_sort_reduce` 在真实工程网格 physics kernel 下优先跑 `1,2,4`，避免排序和 COO 暂存主导总成本。
- 对 macOS AppleClang，先安装 `libomp`，并在报告中记录 `OMP_PROC_BIND` 与 `OMP_PLACES`；这两个变量会影响线程亲和与 NUMA/cache 行为。
