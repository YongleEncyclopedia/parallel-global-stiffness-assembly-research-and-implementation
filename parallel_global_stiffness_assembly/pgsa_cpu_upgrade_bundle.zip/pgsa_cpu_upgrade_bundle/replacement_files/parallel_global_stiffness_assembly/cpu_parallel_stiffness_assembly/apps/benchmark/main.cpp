#include "assembly/assembler_factory.h"
#include "assembly/assembly_plan.h"
#include "core/csr_matrix.h"
#include "core/mesh.h"
#include "core/platform.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#if !defined(_WIN32)
#include <sys/resource.h>
#endif

using namespace fem;

namespace {

struct Config {
  std::string mesh_mode = "cube";
  std::string inp_path;
  std::string case_name;
  ElementType element_type = ElementType::Tet4;
  int nx = 6;
  int ny = 6;
  int nz = 6;
  std::vector<AlgorithmType> algorithms;
  std::vector<int> thread_counts;
  KernelType kernel = KernelType::Simplified;
  int warmup = 0;
  int repeat = 1;
  bool check = false;
  bool emit_skip_records = false;
  std::string csv_path = "benchmark_results_cpu.csv";
  std::string json_path;
  std::string summary_md_path;
  Size max_transient_bytes = static_cast<Size>(8ull * 1024ull * 1024ull * 1024ull);
  Real young = constants::DEFAULT_YOUNG_MODULUS;
  Real poisson = constants::DEFAULT_POISSON_RATIO;
};

struct SampleSummary {
  double mean = 0.0;
  double min = 0.0;
  double max = 0.0;
  double stddev = 0.0;
};

struct RunRecord {
  std::string case_name;
  std::string mesh_name;
  std::string algorithm;
  int threads = 1;
  int omp_threads_effective = 1;
  std::string status = "PASS";  // PASS / FAIL / SKIP
  std::string skip_reason;
  AssemblyStats stats;
  MatrixError error;
  double speedup = 0.0;
  double efficiency = 0.0;
  double preprocess_share = 0.0;
  double peak_rss_mb = 0.0;
  std::string message;
  std::vector<double> assembly_samples_ms;
  std::vector<double> total_samples_ms;
};

std::vector<std::string> split(const std::string& s, char sep) {
  std::vector<std::string> out;
  std::string token;
  std::stringstream ss(s);
  while (std::getline(ss, token, sep)) {
    if (!token.empty()) out.push_back(token);
  }
  return out;
}

std::string env_or_empty(const char* name) {
  const char* value = std::getenv(name);
  return value ? std::string(value) : std::string();
}

std::string csv_escape(const std::string& text) {
  bool needs_quotes = text.find_first_of(",\n\r\"") != std::string::npos;
  std::string escaped;
  escaped.reserve(text.size() + 8);
  for (char ch : text) {
    if (ch == '"') escaped += "\"\"";
    else escaped += ch;
  }
  return needs_quotes ? std::string("\"") + escaped + "\"" : escaped;
}



double phase_ms(const AssemblyStats& stats, const std::string& name) {
  const auto it = stats.phase_times_ms.find(name);
  return it == stats.phase_times_ms.end() ? 0.0 : it->second;
}

std::string json_escape(const std::string& text) {
  std::string out;
  out.reserve(text.size() + 8);
  for (char ch : text) {
    switch (ch) {
      case '\\': out += "\\\\"; break;
      case '"': out += "\\\""; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default: out += ch; break;
    }
  }
  return out;
}

void ensure_parent_dir(const std::string& path) {
  if (path.empty()) return;
  const std::filesystem::path p(path);
  const auto parent = p.parent_path();
  if (!parent.empty()) std::filesystem::create_directories(parent);
}

SampleSummary summarize(const std::vector<double>& values) {
  SampleSummary s;
  if (values.empty()) return s;
  s.min = *std::min_element(values.begin(), values.end());
  s.max = *std::max_element(values.begin(), values.end());
  s.mean = std::accumulate(values.begin(), values.end(), 0.0) / static_cast<double>(values.size());
  if (values.size() > 1) {
    double sq = 0.0;
    for (double v : values) sq += (v - s.mean) * (v - s.mean);
    s.stddev = std::sqrt(sq / static_cast<double>(values.size() - 1));
  }
  return s;
}

std::string short_algorithm_name(AlgorithmType type) {
  switch (type) {
    case AlgorithmType::CpuSerial: return "serial";
    case AlgorithmType::CpuAtomic: return "atomic";
    case AlgorithmType::CpuPrivateCsr: return "private_csr";
    case AlgorithmType::CpuCooSortReduce: return "coo_sort_reduce";
    case AlgorithmType::CpuGraphColoring: return "coloring";
    case AlgorithmType::CpuRowOwner: return "row_owner";
  }
  return algorithm_to_string(type);
}

std::vector<AlgorithmType> parse_algorithms(const std::string& text) {
  if (to_lower_ascii(text) == "all") return AssemblerFactory::get_available_algorithms();
  std::vector<AlgorithmType> out;
  for (const auto& token : split(text, ',')) out.push_back(parse_algorithm_type(token));
  return out;
}

std::vector<int> parse_threads_list(const std::string& text) {
  std::vector<int> out;
  for (const auto& token : split(text, ',')) out.push_back(std::stoi(token));
  return out;
}

std::vector<int> threads_all() {
  const int max_threads = std::max(1, max_thread_count());
  std::vector<int> out;
  out.reserve(static_cast<std::size_t>(max_threads));
  for (int t = 1; t <= max_threads; ++t) out.push_back(t);
  return out;
}

std::vector<int> parse_threads_range(const std::string& text) {
  const auto parts = split(text, ':');
  if (parts.size() < 2 || parts.size() > 3) {
    throw std::invalid_argument("--threads-range 需要 a:b[:step] 格式");
  }
  const int begin = std::stoi(parts[0]);
  const int end = std::stoi(parts[1]);
  const int step = parts.size() == 3 ? std::stoi(parts[2]) : 1;
  if (step <= 0) throw std::invalid_argument("--threads-range 的 step 必须大于 0");
  std::vector<int> out;
  for (int t = begin; t <= end; t += step) out.push_back(t);
  return out;
}

void normalize_threads(std::vector<int>& threads) {
  if (threads.empty()) threads = threads_all();
  std::sort(threads.begin(), threads.end());
  threads.erase(std::unique(threads.begin(), threads.end()), threads.end());
  threads.erase(std::remove_if(threads.begin(), threads.end(), [](int t) { return t <= 0; }), threads.end());
  if (threads.empty()) throw std::invalid_argument("线程列表为空或非法");
}

void print_usage(const char* exe) {
  std::cout
      << "CPU 并行全局刚度矩阵装配 Benchmark\n\n"
      << "用法:\n  " << exe << " [options]\n\n"
      << "核心选项:\n"
      << "  --mesh cube|inp                    网格来源，默认 cube\n"
      << "  --element tet4|hex8                规则 cube 的单元类型，默认 tet4\n"
      << "  --nx N --ny N --nz N               规则 cube 分辨率，默认 6 6 6\n"
      << "  --inp PATH                         Abaqus .inp 路径；用于 --mesh inp\n"
      << "  --case-name NAME                   写入 CSV/JSON/摘要的实验名称\n"
      << "  --algo LIST                        serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner,all\n"
      << "  --threads N                        单一线程数\n"
      << "  --threads-list 1,2,4,8             显式线程列表\n"
      << "  --threads-all                      扫描 1..max_thread_count()\n"
      << "  --threads-range a:b[:step]         扫描闭区间线程范围\n"
      << "  --kernel simplified|physics_tet4   局部刚度核\n"
      << "  --warmup N --repeat N              预热/重复次数，默认 0/1\n"
      << "  --check                            与 serial 基线比较正确性\n"
      << "  --max-memory-gb X                  瞬时内存保护，默认 8\n"
      << "  --emit-skip-records                把跳过项也写入 CSV/JSON\n"
      << "\n输出选项:\n"
      << "  --csv PATH                         CSV 输出路径\n"
      << "  --json PATH                        JSON 输出路径\n"
      << "  --summary-md PATH                  中文 Markdown 摘要输出路径\n"
      << "  --help                             显示帮助\n";
}

Config parse_args(int argc, char** argv) {
  Config cfg;
  cfg.algorithms = AssemblerFactory::get_available_algorithms();
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    auto require_value = [&](const std::string& name) -> std::string {
      if (i + 1 >= argc) throw std::invalid_argument("Missing value for " + name);
      return argv[++i];
    };
    if (arg == "--help" || arg == "-h") {
      print_usage(argv[0]);
      std::exit(0);
    } else if (arg == "--mesh") cfg.mesh_mode = require_value(arg);
    else if (arg == "--element") cfg.element_type = parse_element_type(require_value(arg));
    else if (arg == "--nx") cfg.nx = std::stoi(require_value(arg));
    else if (arg == "--ny") cfg.ny = std::stoi(require_value(arg));
    else if (arg == "--nz") cfg.nz = std::stoi(require_value(arg));
    else if (arg == "--inp") cfg.inp_path = require_value(arg);
    else if (arg == "--case-name") cfg.case_name = require_value(arg);
    else if (arg == "--algo" || arg == "--algorithms") cfg.algorithms = parse_algorithms(require_value(arg));
    else if (arg == "--threads") cfg.thread_counts = {std::stoi(require_value(arg))};
    else if (arg == "--threads-list") cfg.thread_counts = parse_threads_list(require_value(arg));
    else if (arg == "--threads-all") cfg.thread_counts = threads_all();
    else if (arg == "--threads-range") cfg.thread_counts = parse_threads_range(require_value(arg));
    else if (arg == "--kernel") cfg.kernel = parse_kernel_type(require_value(arg));
    else if (arg == "--warmup") cfg.warmup = std::max(0, std::stoi(require_value(arg)));
    else if (arg == "--repeat") cfg.repeat = std::max(1, std::stoi(require_value(arg)));
    else if (arg == "--check") cfg.check = true;
    else if (arg == "--emit-skip-records") cfg.emit_skip_records = true;
    else if (arg == "--csv") cfg.csv_path = require_value(arg);
    else if (arg == "--json") cfg.json_path = require_value(arg);
    else if (arg == "--summary-md") cfg.summary_md_path = require_value(arg);
    else if (arg == "--max-memory-gb") {
      const double gb = std::stod(require_value(arg));
      cfg.max_transient_bytes = static_cast<Size>(gb * 1024.0 * 1024.0 * 1024.0);
    } else if (arg == "--young") cfg.young = std::stod(require_value(arg));
    else if (arg == "--poisson") cfg.poisson = std::stod(require_value(arg));
    else throw std::invalid_argument("Unknown argument: " + arg);
  }
  normalize_threads(cfg.thread_counts);
  return cfg;
}

bool looks_like_git_lfs_pointer(const std::string& path) {
  std::ifstream in(path, std::ios::binary);
  if (!in) return false;
  std::string head(256, '\0');
  in.read(head.data(), static_cast<std::streamsize>(head.size()));
  head.resize(static_cast<std::size_t>(in.gcount()));
  return head.find("version https://git-lfs.github.com/spec/v1") != std::string::npos;
}

Mesh build_mesh(const Config& cfg) {
  if (to_lower_ascii(cfg.mesh_mode) == "cube") {
    if (cfg.element_type == ElementType::Tet4) return Mesh::make_cube_tet4(cfg.nx, cfg.ny, cfg.nz);
    return Mesh::make_cube_hex8(cfg.nx, cfg.ny, cfg.nz);
  }
  if (to_lower_ascii(cfg.mesh_mode) == "inp") {
    if (cfg.inp_path.empty()) throw std::invalid_argument("--mesh inp requires --inp PATH");
    if (looks_like_git_lfs_pointer(cfg.inp_path)) {
      throw std::runtime_error("真实工程网格仍是 Git LFS pointer，尚未 materialize。请先运行：git lfs install && git lfs pull");
    }
    return Mesh::load_from_inp(cfg.inp_path);
  }
  throw std::invalid_argument("Unsupported mesh mode: " + cfg.mesh_mode);
}

std::string default_case_name(const Config& cfg, const Mesh& mesh) {
  if (!cfg.case_name.empty()) return cfg.case_name;
  std::ostringstream oss;
  oss << mesh.name << '_' << kernel_type_to_string(cfg.kernel);
  return oss.str();
}

double peak_rss_mb() {
#if defined(_WIN32)
  return 0.0;
#else
  rusage usage{};
  if (getrusage(RUSAGE_SELF, &usage) != 0) return 0.0;
#if defined(__APPLE__)
  return static_cast<double>(usage.ru_maxrss) / (1024.0 * 1024.0);
#else
  return static_cast<double>(usage.ru_maxrss) / 1024.0;
#endif
#endif
}

bool should_classify_as_skip(const std::string& message) {
  const std::string m = to_lower_ascii(message);
  return m.find("memory") != std::string::npos ||
         m.find("exceed") != std::string::npos ||
         m.find("too large") != std::string::npos ||
         m.find("unsupported") != std::string::npos ||
         m.find("not available") != std::string::npos ||
         m.find("skip") != std::string::npos;
}

RunRecord make_skip_record(const std::string& case_name,
                           const Mesh& mesh,
                           AlgorithmType algo,
                           int threads,
                           const std::string& reason) {
  RunRecord record;
  record.case_name = case_name;
  record.mesh_name = mesh.name;
  record.algorithm = short_algorithm_name(algo);
  record.threads = threads;
  record.omp_threads_effective = effective_thread_count(threads);
  record.status = "SKIP";
  record.skip_reason = reason;
  record.message = reason;
  record.peak_rss_mb = peak_rss_mb();
  return record;
}

RunRecord run_one(AlgorithmType algo,
                  int threads,
                  const Config& cfg,
                  const std::string& case_name,
                  const Mesh& mesh,
                  const CsrMatrix& csr,
                  const AssemblyPlan& plan,
                  const CsrMatrix* reference,
                  double serial_time_ms) {
  RunRecord record;
  record.case_name = case_name;
  record.mesh_name = mesh.name;
  record.algorithm = short_algorithm_name(algo);
  record.threads = threads;
  record.omp_threads_effective = effective_thread_count(threads);

  AssemblyOptions options;
  options.threads = threads;
  options.kernel = cfg.kernel;
  options.max_transient_bytes = cfg.max_transient_bytes;
  options.young_modulus = cfg.young;
  options.poisson_ratio = cfg.poisson;

  try {
    auto assembler = AssemblerFactory::create(algo, options);
    assembler->set_problem(mesh, csr, plan);

    const auto prep0 = std::chrono::steady_clock::now();
    assembler->prepare();
    const auto prep1 = std::chrono::steady_clock::now();

    auto stats = assembler->get_stats();
    if (stats.preprocess_time_ms == 0.0) {
      stats.preprocess_time_ms = std::chrono::duration<double, std::milli>(prep1 - prep0).count();
    }

    for (int i = 0; i < cfg.warmup; ++i) assembler->assemble();

    for (int i = 0; i < cfg.repeat; ++i) {
      assembler->assemble();
      const auto s = assembler->get_stats();
      record.assembly_samples_ms.push_back(s.assembly_time_ms);
      record.total_samples_ms.push_back(stats.preprocess_time_ms + s.assembly_time_ms);
    }

    stats = assembler->get_stats();
    const auto assembly = summarize(record.assembly_samples_ms);
    const auto total = summarize(record.total_samples_ms);
    stats.assembly_time_ms = assembly.mean;
    stats.total_time_ms = total.mean;
    if (!stats.diagnostics.empty()) record.message = stats.diagnostics;

    record.stats = stats;
    record.peak_rss_mb = peak_rss_mb();
    if (reference) record.error = compare_values(*reference, assembler->get_result());

    record.speedup = stats.assembly_time_ms > 0.0 ? serial_time_ms / stats.assembly_time_ms : 0.0;
    record.efficiency = threads > 0 ? record.speedup / static_cast<double>(threads) : 0.0;
    record.preprocess_share = stats.total_time_ms > 0.0 ? stats.preprocess_time_ms / stats.total_time_ms : 0.0;

    if (cfg.check && reference && (!record.error.same_structure || record.error.relative_l2 > 1.0e-8)) {
      record.status = "FAIL";
      record.message = "correctness check failed";
    }
  } catch (const std::exception& ex) {
    record.status = should_classify_as_skip(ex.what()) ? "SKIP" : "FAIL";
    record.skip_reason = record.status == "SKIP" ? ex.what() : "";
    record.message = ex.what();
    record.peak_rss_mb = peak_rss_mb();
  }
  return record;
}

void write_csv_header(std::ofstream& out) {
  out << "case_name,mesh,element_type,kernel,nodes,elements,dofs,nnz,algorithm,threads,"
      << "omp_threads_effective,run_count,preprocess_ms,"
      << "assembly_mean,assembly_min,assembly_max,assembly_std,"
      << "total_mean,total_min,total_max,total_std,"
      << "efficiency,preprocess_share,rel_l2,max_abs,speedup,"
      << "extra_memory_bytes,peak_rss_mb,status,skip_reason,colors,diagnostics,"
      << "phase_alloc_zero_ms,phase_element_assemble_ms,phase_nnz_reduce_ms,"
      << "phase_local_generate_ms,phase_merge_ms,phase_sort_ms,phase_reduce_ms,"
      << "phase_owner_partition_ms,phase_numeric_ms,"
      << "omp_proc_bind,omp_places,omp_dynamic,platform\n";
}

void write_csv_record(std::ofstream& out,
                      const Mesh& mesh,
                      const CsrMatrix& csr,
                      const RunRecord& r,
                      KernelType kernel) {
  const auto assembly = summarize(r.assembly_samples_ms);
  const auto total = summarize(r.total_samples_ms);
  out << csv_escape(r.case_name) << ','
      << csv_escape(mesh.name) << ','
      << element_type_to_string(mesh.dominant_element_type()) << ','
      << kernel_type_to_string(kernel) << ','
      << mesh.num_nodes() << ',' << mesh.num_elements() << ',' << mesh.num_dofs() << ',' << csr.nnz() << ','
      << r.algorithm << ',' << r.threads << ',' << r.omp_threads_effective << ','
      << r.assembly_samples_ms.size() << ','
      << std::setprecision(10)
      << r.stats.preprocess_time_ms << ','
      << assembly.mean << ',' << assembly.min << ',' << assembly.max << ',' << assembly.stddev << ','
      << total.mean << ',' << total.min << ',' << total.max << ',' << total.stddev << ','
      << r.efficiency << ',' << r.preprocess_share << ','
      << r.error.relative_l2 << ',' << r.error.max_abs << ',' << r.speedup << ','
      << r.stats.extra_memory_bytes << ',' << r.peak_rss_mb << ','
      << r.status << ',' << csv_escape(r.skip_reason) << ',' << r.stats.colors << ','
      << csv_escape(r.message) << ','
      << phase_ms(r.stats, "alloc_zero") << ','
      << phase_ms(r.stats, "element_assemble") << ','
      << phase_ms(r.stats, "nnz_reduce") << ','
      << phase_ms(r.stats, "local_generate") << ','
      << phase_ms(r.stats, "merge") << ','
      << phase_ms(r.stats, "sort") << ','
      << phase_ms(r.stats, "reduce") << ','
      << phase_ms(r.stats, "owner_partition") << ','
      << phase_ms(r.stats, "numeric") << ','
      << csv_escape(env_or_empty("OMP_PROC_BIND")) << ','
      << csv_escape(env_or_empty("OMP_PLACES")) << ','
      << csv_escape(env_or_empty("OMP_DYNAMIC")) << ','
      << csv_escape(platform_info_compact()) << "\n";
}

void write_json(const std::string& path,
                const Config& cfg,
                const Mesh& mesh,
                const CsrMatrix& csr,
                const std::vector<RunRecord>& records) {
  if (path.empty()) return;
  ensure_parent_dir(path);
  std::ofstream out(path);
  if (!out) throw std::runtime_error("Cannot write JSON: " + path);
  out << "{\n";
  out << "  \"case_name\": \"" << json_escape(records.empty() ? cfg.case_name : records.front().case_name) << "\",\n";
  out << "  \"mesh\": {\"name\": \"" << json_escape(mesh.name) << "\", \"nodes\": " << mesh.num_nodes()
      << ", \"elements\": " << mesh.num_elements() << ", \"dofs\": " << mesh.num_dofs()
      << ", \"nnz\": " << csr.nnz() << "},\n";
  out << "  \"kernel\": \"" << kernel_type_to_string(cfg.kernel) << "\",\n";
  out << "  \"platform\": \"" << json_escape(platform_info_compact()) << "\",\n";
  out << "  \"openmp_environment\": {\n"
      << "    \"OMP_PROC_BIND\": \"" << json_escape(env_or_empty("OMP_PROC_BIND")) << "\",\n"
      << "    \"OMP_PLACES\": \"" << json_escape(env_or_empty("OMP_PLACES")) << "\",\n"
      << "    \"OMP_DYNAMIC\": \"" << json_escape(env_or_empty("OMP_DYNAMIC")) << "\"\n"
      << "  },\n";
  out << "  \"records\": [\n";
  for (std::size_t i = 0; i < records.size(); ++i) {
    const auto& r = records[i];
    const auto assembly = summarize(r.assembly_samples_ms);
    const auto total = summarize(r.total_samples_ms);
    out << "    {"
        << "\"algorithm\": \"" << json_escape(r.algorithm) << "\", "
        << "\"threads\": " << r.threads << ", "
        << "\"omp_threads_effective\": " << r.omp_threads_effective << ", "
        << "\"status\": \"" << r.status << "\", "
        << "\"skip_reason\": \"" << json_escape(r.skip_reason) << "\", "
        << "\"run_count\": " << r.assembly_samples_ms.size() << ", "
        << "\"preprocess_ms\": " << r.stats.preprocess_time_ms << ", "
        << "\"assembly_mean\": " << assembly.mean << ", "
        << "\"assembly_min\": " << assembly.min << ", "
        << "\"assembly_max\": " << assembly.max << ", "
        << "\"assembly_std\": " << assembly.stddev << ", "
        << "\"total_mean\": " << total.mean << ", "
        << "\"total_min\": " << total.min << ", "
        << "\"total_max\": " << total.max << ", "
        << "\"total_std\": " << total.stddev << ", "
        << "\"speedup\": " << r.speedup << ", "
        << "\"efficiency\": " << r.efficiency << ", "
        << "\"preprocess_share\": " << r.preprocess_share << ", "
        << "\"peak_rss_mb\": " << r.peak_rss_mb << ", "
        << "\"extra_memory_bytes\": " << r.stats.extra_memory_bytes << ", "
        << "\"rel_l2\": " << r.error.relative_l2 << ", "
        << "\"max_abs\": " << r.error.max_abs << ", "
        << "\"diagnostics\": \"" << json_escape(r.message) << "\", "
        << "\"phase_times_ms\": {"
        << "\"alloc_zero\": " << phase_ms(r.stats, "alloc_zero") << ", "
        << "\"element_assemble\": " << phase_ms(r.stats, "element_assemble") << ", "
        << "\"nnz_reduce\": " << phase_ms(r.stats, "nnz_reduce") << ", "
        << "\"local_generate\": " << phase_ms(r.stats, "local_generate") << ", "
        << "\"merge\": " << phase_ms(r.stats, "merge") << ", "
        << "\"sort\": " << phase_ms(r.stats, "sort") << ", "
        << "\"reduce\": " << phase_ms(r.stats, "reduce") << ", "
        << "\"owner_partition\": " << phase_ms(r.stats, "owner_partition") << ", "
        << "\"numeric\": " << phase_ms(r.stats, "numeric")
        << "}"
        << "}" << (i + 1 == records.size() ? "\n" : ",\n");
  }
  out << "  ]\n";
  out << "}\n";
}

const RunRecord* best_pass_by_metric(const std::vector<RunRecord>& records,
                                     const std::string& metric,
                                     bool lower_is_better) {
  const RunRecord* best = nullptr;
  for (const auto& r : records) {
    if (r.status != "PASS") continue;
    const auto assembly = summarize(r.assembly_samples_ms);
    const auto total = summarize(r.total_samples_ms);
    double value = 0.0;
    if (metric == "assembly") value = assembly.mean;
    else if (metric == "memory") value = static_cast<double>(r.stats.extra_memory_bytes);
    else if (metric == "preprocess_share") value = r.preprocess_share;
    else if (metric == "speedup") value = r.speedup;
    else if (metric == "total") value = total.mean;
    else value = assembly.mean;

    if (!best) best = &r;
    else {
      const auto best_assembly = summarize(best->assembly_samples_ms);
      const auto best_total = summarize(best->total_samples_ms);
      double best_value = 0.0;
      if (metric == "assembly") best_value = best_assembly.mean;
      else if (metric == "memory") best_value = static_cast<double>(best->stats.extra_memory_bytes);
      else if (metric == "preprocess_share") best_value = best->preprocess_share;
      else if (metric == "speedup") best_value = best->speedup;
      else if (metric == "total") best_value = best_total.mean;
      else best_value = best_assembly.mean;
      if ((lower_is_better && value < best_value) || (!lower_is_better && value > best_value)) best = &r;
    }
  }
  return best;
}

void write_summary_md(const std::string& path,
                      const Config& cfg,
                      const Mesh& mesh,
                      const CsrMatrix& csr,
                      const std::vector<RunRecord>& records) {
  if (path.empty()) return;
  ensure_parent_dir(path);
  std::ofstream out(path);
  if (!out) throw std::runtime_error("Cannot write summary Markdown: " + path);

  const RunRecord* fastest = best_pass_by_metric(records, "assembly", true);
  const RunRecord* lowest_memory = best_pass_by_metric(records, "memory", true);
  const RunRecord* heaviest_prep = best_pass_by_metric(records, "preprocess_share", false);
  const RunRecord* best_speedup = best_pass_by_metric(records, "speedup", false);

  out << "# CPU 并行刚度矩阵装配实验摘要\n\n";
  out << "- case_name: `" << (records.empty() ? cfg.case_name : records.front().case_name) << "`\n";
  out << "- mesh: `" << mesh.name << "`, nodes=" << mesh.num_nodes()
      << ", elements=" << mesh.num_elements() << ", dofs=" << mesh.num_dofs()
      << ", nnz=" << csr.nnz() << "\n";
  out << "- kernel: `" << kernel_type_to_string(cfg.kernel) << "`\n";
  out << "- platform: `" << platform_info_compact() << "`\n";
  out << "- OpenMP: OMP_PROC_BIND=`" << env_or_empty("OMP_PROC_BIND")
      << "`, OMP_PLACES=`" << env_or_empty("OMP_PLACES")
      << "`, OMP_DYNAMIC=`" << env_or_empty("OMP_DYNAMIC") << "`\n\n";

  auto describe = [](const RunRecord* r, const std::string& metric) -> std::string {
    if (!r) return "无 PASS 记录";
    std::ostringstream oss;
    const auto assembly = summarize(r->assembly_samples_ms);
    oss << '`' << r->algorithm << "` @ " << r->threads << " threads, " << metric
        << ", assembly_mean=" << std::fixed << std::setprecision(3) << assembly.mean
        << " ms, speedup=" << std::setprecision(2) << r->speedup;
    return oss.str();
  };

  out << "## 自动结论\n\n";
  out << "- 最快装配算法：" << describe(fastest, "最低 assembly_mean") << "。\n";
  out << "- 最省额外内存算法：" << describe(lowest_memory, "最低 extra_memory_bytes") << "。\n";
  out << "- 预处理占比最高算法：" << describe(heaviest_prep, "最高 preprocess_share") << "。\n";
  out << "- 最佳加速比：" << describe(best_speedup, "最高 speedup") << "。\n";
  out << "- 后续建议：优先观察真实网格与规则网格中最快算法是否一致；若 coloring/private_csr 在真实网格上预处理占比过高，应把优化重点放在预处理复用与内存峰值控制。\n\n";

  out << "## 记录表\n\n";
  out << "| algorithm | threads | status | assembly_mean(ms) | total_mean(ms) | speedup | efficiency | preprocess_share | extra_memory(bytes) | note |\n";
  out << "|---|---:|---|---:|---:|---:|---:|---:|---:|---|\n";
  for (const auto& r : records) {
    const auto assembly = summarize(r.assembly_samples_ms);
    const auto total = summarize(r.total_samples_ms);
    out << "| " << r.algorithm << " | " << r.threads << " | " << r.status
        << " | " << std::fixed << std::setprecision(3) << assembly.mean
        << " | " << total.mean
        << " | " << std::setprecision(3) << r.speedup
        << " | " << r.efficiency
        << " | " << r.preprocess_share
        << " | " << r.stats.extra_memory_bytes
        << " | " << (r.status == "SKIP" ? r.skip_reason : r.message) << " |\n";
  }
}

}  // namespace

int main(int argc, char** argv) {
  try {
    Config cfg = parse_args(argc, argv);

    const auto t_mesh0 = std::chrono::steady_clock::now();
    Mesh mesh = build_mesh(cfg);
    const auto t_mesh1 = std::chrono::steady_clock::now();
    CsrMatrix csr = CsrMatrix::build_sparsity(mesh);
    const auto t_csr1 = std::chrono::steady_clock::now();
    AssemblyPlan plan = build_assembly_plan(mesh, csr);
    const auto t_plan1 = std::chrono::steady_clock::now();

    const std::string case_name = default_case_name(cfg, mesh);
    const double mesh_ms = std::chrono::duration<double, std::milli>(t_mesh1 - t_mesh0).count();
    const double csr_ms = std::chrono::duration<double, std::milli>(t_csr1 - t_mesh1).count();
    const double plan_ms = std::chrono::duration<double, std::milli>(t_plan1 - t_csr1).count();

    std::cout << "============================================================\n";
    std::cout << " CPU 并行全局刚度矩阵装配 Benchmark\n";
    std::cout << "============================================================\n";
    std::cout << "case_name=" << case_name << "\n";
    std::cout << mesh_summary(mesh) << "\n";
    std::cout << "nnz=" << csr.nnz() << ", csr_memory=" << memory_string(csr.bytes())
              << ", plan_memory=" << memory_string(plan.bytes()) << "\n";
    std::cout << "kernel=" << kernel_type_to_string(cfg.kernel)
              << ", platform=" << platform_info_compact() << "\n";
    std::cout << "OpenMP 环境: OMP_PROC_BIND=" << env_or_empty("OMP_PROC_BIND")
              << ", OMP_PLACES=" << env_or_empty("OMP_PLACES")
              << ", OMP_DYNAMIC=" << env_or_empty("OMP_DYNAMIC") << "\n";
    std::cout << "预计算: mesh=" << mesh_ms << " ms, csr=" << csr_ms
              << " ms, scatter_plan=" << plan_ms << " ms\n\n";

    CsrMatrix reference;
    RunRecord baseline;
    {
      baseline = run_one(AlgorithmType::CpuSerial, 1, cfg, case_name, mesh, csr, plan, nullptr, 0.0);
      if (baseline.status != "PASS") throw std::runtime_error("Serial baseline failed: " + baseline.message);

      AssemblyOptions options;
      options.kernel = cfg.kernel;
      options.young_modulus = cfg.young;
      options.poisson_ratio = cfg.poisson;
      options.max_transient_bytes = cfg.max_transient_bytes;
      auto assembler = AssemblerFactory::create(AlgorithmType::CpuSerial, options);
      assembler->set_problem(mesh, csr, plan);
      assembler->prepare();
      assembler->assemble();
      reference = assembler->get_result();
      baseline.speedup = 1.0;
      baseline.efficiency = 1.0;
      baseline.error = compare_values(reference, reference);
    }

    const double serial_time_ms = baseline.stats.assembly_time_ms;

    ensure_parent_dir(cfg.csv_path);
    std::ofstream csv(cfg.csv_path);
    if (!csv) throw std::runtime_error("Cannot write CSV: " + cfg.csv_path);
    write_csv_header(csv);

    std::vector<RunRecord> records;
    records.reserve(cfg.thread_counts.size() * cfg.algorithms.size());

    std::cout << std::left << std::setw(18) << "algorithm"
              << std::right << std::setw(8) << "threads"
              << std::setw(8) << "eff_omp"
              << std::setw(12) << "runs"
              << std::setw(14) << "prep_ms"
              << std::setw(14) << "asm_mean"
              << std::setw(12) << "speedup"
              << std::setw(12) << "eff"
              << std::setw(14) << "rel_l2"
              << std::setw(10) << "status" << "\n";
    std::cout << std::string(104, '-') << "\n";

    for (int threads : cfg.thread_counts) {
      for (AlgorithmType algo : cfg.algorithms) {
        RunRecord rec;
        if (algo == AlgorithmType::CpuSerial && threads != 1) {
          rec = make_skip_record(case_name, mesh, algo, threads, "serial 仅作为 1 线程基线运行");
          if (!cfg.emit_skip_records) continue;
        } else if (algo == AlgorithmType::CpuSerial) {
          rec = baseline;
          rec.case_name = case_name;
          rec.mesh_name = mesh.name;
          rec.threads = 1;
          rec.omp_threads_effective = effective_thread_count(1);
        } else {
          const CsrMatrix* ref_ptr = cfg.check ? &reference : nullptr;
          rec = run_one(algo, threads, cfg, case_name, mesh, csr, plan, ref_ptr, serial_time_ms);
          if (rec.status == "SKIP" && !cfg.emit_skip_records) {
            std::cout << short_algorithm_name(algo) << " @ " << threads << " threads SKIP: " << rec.message << "\n";
            continue;
          }
        }

        const auto assembly = summarize(rec.assembly_samples_ms);
        std::cout << std::left << std::setw(18) << rec.algorithm
                  << std::right << std::setw(8) << rec.threads
                  << std::setw(8) << rec.omp_threads_effective
                  << std::setw(12) << rec.assembly_samples_ms.size()
                  << std::setw(14) << std::fixed << std::setprecision(3) << rec.stats.preprocess_time_ms
                  << std::setw(14) << assembly.mean
                  << std::setw(12) << std::setprecision(3) << rec.speedup
                  << std::setw(12) << rec.efficiency
                  << std::setw(14) << std::scientific << std::setprecision(2) << rec.error.relative_l2
                  << std::setw(10) << rec.status << "\n";
        if ((rec.status != "PASS") && !rec.message.empty()) {
          std::cout << "  说明: " << rec.message << "\n";
        }

        write_csv_record(csv, mesh, csr, rec, cfg.kernel);
        records.push_back(rec);
      }
    }

    write_json(cfg.json_path, cfg, mesh, csr, records);
    write_summary_md(cfg.summary_md_path, cfg, mesh, csr, records);

    std::cout << "\nCSV 已保存到: " << cfg.csv_path << "\n";
    if (!cfg.json_path.empty()) std::cout << "JSON 已保存到: " << cfg.json_path << "\n";
    if (!cfg.summary_md_path.empty()) std::cout << "中文摘要已保存到: " << cfg.summary_md_path << "\n";
    return 0;
  } catch (const std::exception& ex) {
    std::cerr << "错误: " << ex.what() << "\n";
    return 1;
  }
}
