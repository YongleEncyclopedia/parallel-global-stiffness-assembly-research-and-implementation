# 示例与实验数据使用规则

## 规则网格

规则网格用于快速回归、算法比较和 strong-scaling 初筛。推荐默认组合：

```text
--mesh cube --element tet4 --nx 8 --ny 8 --nz 8 --kernel simplified
```

## 真实工程网格

真实工程网格用于验证规则网格趋势是否能迁移到非均匀结构。当前默认示例：

```text
examples/3d-WindTurbineHub.inp
```

运行前必须确认该文件不是 Git LFS pointer。若文件头包含：

```text
version https://git-lfs.github.com/spec/v1
```

则应中止并提示运行：

```bash
git lfs install
git lfs pull
```

## 结果目录

统一归档到：

```text
results/YYYY-MM-DD/<case>/<kernel>/{csv,json,figures,summaries}
```

目录名使用英文和数字，便于脚本处理；Markdown 摘要和图表文本使用中文。
