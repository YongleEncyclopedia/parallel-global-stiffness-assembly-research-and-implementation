function mesh = create_demo_mesh()
% CREATE_DEMO_MESH  生成一个小型非结构三角形网格，用于测试和演示。
%
% 在单位正方形 [0,1] x [0,1] 内手工布置 12 个散点，
% 然后调用 MATLAB 的 delaunayTriangulation 进行三角剖分。
% 点集故意设置为不均匀分布，以得到真正的非结构网格。
%
% 输出字段：
%   mesh.nodes    - (nVertex x 2)  各节点的坐标 [x, y]
%   mesh.cells    - (nCell   x 3)  各三角形的顶点编号（1-based）
%   mesh.nVertex  - 顶点总数
%   mesh.nCell    - 三角形单元总数

% -----------------------------------------------------------------------
% 手工布置的散点坐标（固定，保证每次剖分结果一致）
% -----------------------------------------------------------------------
pts = [
    0.00  0.00
    0.50  0.00
    1.00  0.00
    0.00  0.50
    0.30  0.35
    0.70  0.25
    1.00  0.50
    0.20  0.80
    0.60  0.70
    1.00  1.00
    0.00  1.00
    0.50  1.00
];

% -----------------------------------------------------------------------
% Delaunay 三角剖分
% -----------------------------------------------------------------------
DT = delaunayTriangulation(pts(:,1), pts(:,2));

mesh.nodes   = DT.Points;           % nVertex x 2，节点坐标
mesh.cells   = DT.ConnectivityList; % nCell   x 3，每行是一个三角形的三个顶点编号
mesh.nVertex = size(mesh.nodes, 1);
mesh.nCell   = size(mesh.cells, 1);

fprintf('[create_demo_mesh] 顶点数 nVertex=%d  单元数 nCell=%d\n', ...
        mesh.nVertex, mesh.nCell);
end
