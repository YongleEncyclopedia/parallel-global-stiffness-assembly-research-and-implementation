function section = build_section(topo, disc)
% BUILD_SECTION  为每个拓扑点建立（自由度数，全局偏移量）的映射关系。
%
% 【对应 PETSc 概念】
% 直接类比于 PETSc 中的 PetscSection：
%   PetscSectionSetDof(s, point, ndof)   ← 设置每点的自由度数
%   PetscSectionSetUp(s)                 ← 计算各点的全局偏移量
%
% 调用本函数后：
%   section.ndof(p)   = 点 p 上挂载的自由度数量
%   section.offset(p) = 点 p 在全局 DOF 向量中第一个自由度的偏移（0-based）
%
% 点 p 的第 k 个全局自由度下标（1-based，MATLAB 惯例）为：
%   section.offset(p) + k，其中 k = 1 .. ndof(p)
%
% 输入：
%   topo  - 网格拓扑结构体（来自 build_mesh_topology）
%   disc  - 离散化参数结构体（来自 create_discretization）
%
% 输出：
%   section.nPoints    - 拓扑点总数
%   section.ndof       - (nPoints x 1) 每点的自由度数
%   section.offset     - (nPoints x 1) 每点的全局偏移（0-based）
%   section.totalDofs  - 全局自由度总数 N

nP = topo.nPoints;
section.nPoints = nP;
section.ndof    = zeros(nP, 1);
section.offset  = zeros(nP, 1);

% -----------------------------------------------------------------------
% 按层（stratum）为每个点赋自由度数
% 对应 PETSc 的 PetscSectionSetDof
% -----------------------------------------------------------------------
for p = topo.pVertexStart : topo.pVertexEnd
    section.ndof(p) = disc.dofsPerVertex;
end
for p = topo.pEdgeStart : topo.pEdgeEnd
    section.ndof(p) = disc.dofsPerEdge;
end
for p = topo.pCellStart : topo.pCellEnd
    section.ndof(p) = disc.dofsPerCell;
end

% -----------------------------------------------------------------------
% 计算累积偏移量（0-based）
% 对应 PETSc 的 PetscSectionSetUp
% -----------------------------------------------------------------------
offset = 0;
for p = 1:nP
    section.offset(p) = offset;
    offset = offset + section.ndof(p);
end
section.totalDofs = offset;

fprintf('[build_section] 全局自由度总数 totalDofs=%d\n', section.totalDofs);
end
