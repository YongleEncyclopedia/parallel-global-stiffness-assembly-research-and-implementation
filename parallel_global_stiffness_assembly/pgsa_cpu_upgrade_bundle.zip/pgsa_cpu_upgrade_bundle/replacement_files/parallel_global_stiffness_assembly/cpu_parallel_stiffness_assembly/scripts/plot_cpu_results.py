#!/usr/bin/env python3
"""CPU benchmark plotting and Chinese summary generator.

输入：一个或多个 benchmark CSV。
输出：PNG + SVG 图和中文 Markdown 摘要。
兼容旧字段 assembly_ms/total_ms，也优先使用新字段 assembly_mean/total_mean。
"""

from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Iterable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def load_rows(paths: Iterable[Path]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for path in paths:
        with path.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                row.setdefault("source_csv", str(path))
                rows.append(row)
    if not rows:
        raise ValueError("CSV 中没有可绘制的数据")
    return rows


def f(row: dict[str, str], *names: str, default: float = 0.0) -> float:
    for name in names:
        value = row.get(name, "")
        if value not in (None, ""):
            try:
                return float(value)
            except ValueError:
                pass
    return default


def s(row: dict[str, str], *names: str, default: str = "") -> str:
    for name in names:
        value = row.get(name, "")
        if value:
            return value
    return default


def passed(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [row for row in rows if s(row, "status", default="PASS") == "PASS"]


def case_key(row: dict[str, str]) -> str:
    return s(row, "case_name", default=s(row, "mesh", default=Path(row.get("source_csv", "case")).stem))


def group_by(rows: list[dict[str, str]], key: str) -> dict[str, list[dict[str, str]]]:
    groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        groups[s(row, key, default="unknown")].append(row)
    return dict(groups)


def save(fig: plt.Figure, out_dir: Path, stem: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_dir / f"{stem}.png", dpi=220)
    fig.savefig(out_dir / f"{stem}.svg")
    plt.close(fig)


def annotate_line_points(ax: plt.Axes, xs: list[int], ys: list[float], fmt: str) -> None:
    for x, y in zip(xs, ys):
        if math.isfinite(y):
            ax.annotate(fmt.format(y), (x, y), textcoords="offset points", xytext=(0, 6), ha="center", fontsize=8)


def plot_metric_lines(rows: list[dict[str, str]], out_dir: Path, metric: str, ylabel: str, title: str, stem: str) -> None:
    rows = passed(rows)
    if not rows:
        return
    fig, ax = plt.subplots(figsize=(10.5, 6.0))
    for algo, group in sorted(group_by(rows, "algorithm").items()):
        group = sorted(group, key=lambda row: f(row, "threads"))
        xs = [int(f(row, "threads")) for row in group]
        ys = [f(row, metric, metric.replace("_mean", "_ms"), default=0.0) for row in group]
        ax.plot(xs, ys, marker="o", linewidth=2.0, label=algo)
        annotate_line_points(ax, xs, ys, "{:.2f}")
    ax.set_xlabel("线程数 / Threads")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, alpha=0.25)
    ax.legend(loc="best", fontsize=9)
    save(fig, out_dir, stem)


def plot_bar_best(rows: list[dict[str, str]], out_dir: Path, metric: str, ylabel: str, title: str, stem: str, lower: bool = True) -> None:
    rows = passed(rows)
    if not rows:
        return
    best: dict[str, dict[str, str]] = {}
    for row in rows:
        algo = s(row, "algorithm", default="unknown")
        val = f(row, metric, default=0.0)
        if algo not in best or ((val < f(best[algo], metric) if lower else val > f(best[algo], metric))):
            best[algo] = row
    labels = list(sorted(best))
    vals = [f(best[label], metric) for label in labels]
    fig, ax = plt.subplots(figsize=(10.5, 6.0))
    bars = ax.bar(labels, vals)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.tick_params(axis="x", rotation=25)
    for bar, label in zip(bars, labels):
        val = bar.get_height()
        threads = int(f(best[label], "threads"))
        ax.annotate(f"{val:.2f}\nT={threads}", (bar.get_x() + bar.get_width() / 2, val), ha="center", va="bottom", fontsize=8)
    save(fig, out_dir, stem)


def plot_preprocess_breakdown(rows: list[dict[str, str]], out_dir: Path) -> None:
    rows = passed(rows)
    if not rows:
        return
    phase_cols = [
        "phase_alloc_zero_ms", "phase_element_assemble_ms", "phase_nnz_reduce_ms",
        "phase_local_generate_ms", "phase_merge_ms", "phase_sort_ms", "phase_reduce_ms",
        "phase_owner_partition_ms", "phase_numeric_ms",
    ]
    selected = []
    for row in rows:
        phase_sum = sum(f(row, c) for c in phase_cols)
        prep = f(row, "preprocess_ms")
        if phase_sum > 0 or prep > 0:
            selected.append(row)
    if not selected:
        return
    labels = [f"{s(row, 'algorithm')}\nT={int(f(row, 'threads'))}" for row in selected]
    fig, ax = plt.subplots(figsize=(12.5, 6.5))
    bottom = [0.0] * len(selected)
    any_phase = any(sum(f(row, c) for c in phase_cols) > 0 for row in selected)
    cols = phase_cols if any_phase else ["preprocess_ms"]
    for col in cols:
        vals = [f(row, col) for row in selected]
        ax.bar(labels, vals, bottom=bottom, label=col.replace("phase_", "").replace("_ms", ""))
        bottom = [a + b for a, b in zip(bottom, vals)]
    ax.set_ylabel("时间 / ms")
    ax.set_title("预处理与子阶段拆分 / Preprocess breakdown")
    ax.tick_params(axis="x", rotation=25)
    ax.legend(loc="best", fontsize=8)
    for x, total in enumerate(bottom):
        ax.annotate(f"{total:.2f}", (x, total), ha="center", va="bottom", fontsize=8)
    save(fig, out_dir, "preprocess_breakdown")


def plot_memory(rows: list[dict[str, str]], out_dir: Path) -> None:
    rows = passed(rows)
    if not rows:
        return
    best = []
    for algo, group in sorted(group_by(rows, "algorithm").items()):
        row = max(group, key=lambda r: f(r, "extra_memory_bytes"))
        best.append(row)
    labels = [s(row, "algorithm") for row in best]
    vals = [f(row, "extra_memory_bytes") / (1024.0 * 1024.0) for row in best]
    rss = [f(row, "peak_rss_mb") for row in best]
    fig, ax = plt.subplots(figsize=(10.5, 6.0))
    bars = ax.bar(labels, vals, label="extra_memory_MB")
    ax.plot(labels, rss, marker="o", linewidth=2.0, label="peak_rss_MB")
    ax.set_ylabel("内存 / MB")
    ax.set_title("额外内存与峰值 RSS / Extra memory")
    ax.tick_params(axis="x", rotation=25)
    ax.legend(loc="best")
    for bar, val in zip(bars, vals):
        ax.annotate(f"{val:.1f}", (bar.get_x() + bar.get_width() / 2, bar.get_height()), ha="center", va="bottom", fontsize=8)
    save(fig, out_dir, "extra_memory")


def plot_case_comparison(rows: list[dict[str, str]], out_dir: Path, stem: str, title: str) -> None:
    rows = passed(rows)
    if not rows:
        return
    labels = []
    vals = []
    for case, group in sorted(group_by(rows, "case_name").items()):
        fastest = min(group, key=lambda row: f(row, "assembly_mean", "assembly_ms", default=float("inf")))
        labels.append(f"{case}\n{s(fastest, 'algorithm')} T={int(f(fastest, 'threads'))}")
        vals.append(f(fastest, "assembly_mean", "assembly_ms"))
    fig, ax = plt.subplots(figsize=(11.0, 6.0))
    bars = ax.bar(labels, vals)
    ax.set_ylabel("最快装配时间 / ms")
    ax.set_title(title)
    ax.tick_params(axis="x", rotation=20)
    for bar, val in zip(bars, vals):
        ax.annotate(f"{val:.2f}", (bar.get_x() + bar.get_width() / 2, val), ha="center", va="bottom", fontsize=8)
    save(fig, out_dir, stem)


def plot_dashboard(rows: list[dict[str, str]], out_dir: Path) -> None:
    rows = passed(rows)
    if not rows:
        return
    fastest = min(rows, key=lambda row: f(row, "assembly_mean", "assembly_ms", default=float("inf")))
    best_speed = max(rows, key=lambda row: f(row, "speedup"))
    min_mem = min(rows, key=lambda row: f(row, "extra_memory_bytes"))
    fig, ax = plt.subplots(figsize=(11.0, 6.0))
    ax.axis("off")
    text = (
        "CPU 并行刚度矩阵装配综合 Dashboard\n\n"
        f"最快算法: {s(fastest, 'algorithm')} @ T={int(f(fastest, 'threads'))}, "
        f"assembly={f(fastest, 'assembly_mean', 'assembly_ms'):.3f} ms\n"
        f"最高加速比: {s(best_speed, 'algorithm')} @ T={int(f(best_speed, 'threads'))}, "
        f"speedup={f(best_speed, 'speedup'):.2f}\n"
        f"最低额外内存: {s(min_mem, 'algorithm')} @ T={int(f(min_mem, 'threads'))}, "
        f"extra={f(min_mem, 'extra_memory_bytes') / (1024.0 * 1024.0):.2f} MB\n"
        f"PASS 记录数: {len(rows)}"
    )
    ax.text(0.04, 0.92, text, va="top", ha="left", fontsize=15)
    save(fig, out_dir, "dashboard")


def write_summary(rows: list[dict[str, str]], out_dir: Path) -> None:
    ok = passed(rows)
    out = out_dir / "experiment_summary.md"
    if not ok:
        out.write_text("# CPU 实验摘要\n\n没有 PASS 记录。\n", encoding="utf-8")
        return
    fastest = min(ok, key=lambda row: f(row, "assembly_mean", "assembly_ms", default=float("inf")))
    best_speed = max(ok, key=lambda row: f(row, "speedup"))
    min_mem = min(ok, key=lambda row: f(row, "extra_memory_bytes"))
    prep_heavy = max(ok, key=lambda row: f(row, "preprocess_share"))
    lines = [
        "# CPU 实验摘要",
        "",
        f"- 最快算法：`{s(fastest, 'algorithm')}` @ `{int(f(fastest, 'threads'))}` threads，assembly_mean={f(fastest, 'assembly_mean', 'assembly_ms'):.3f} ms。",
        f"- 最高加速比：`{s(best_speed, 'algorithm')}` @ `{int(f(best_speed, 'threads'))}` threads，speedup={f(best_speed, 'speedup'):.2f}。",
        f"- 最省额外内存：`{s(min_mem, 'algorithm')}`，extra_memory={f(min_mem, 'extra_memory_bytes') / (1024.0 * 1024.0):.2f} MB。",
        f"- 预处理最重算法：`{s(prep_heavy, 'algorithm')}`，preprocess_share={f(prep_heavy, 'preprocess_share'):.3f}。",
        "- 趋势判断：请结合 `cube_vs_windhub` 与 `simplified_vs_physics_tet4` 两张图确认规则网格、真实网格、简化核、物理核之间是否一致。",
        "",
        "## 每个 case 的最快记录",
        "",
        "| case | algorithm | threads | assembly_mean(ms) | speedup |",
        "|---|---|---:|---:|---:|",
    ]
    for case, group in sorted(group_by(ok, "case_name").items()):
        row = min(group, key=lambda r: f(r, "assembly_mean", "assembly_ms", default=float("inf")))
        lines.append(f"| {case} | {s(row, 'algorithm')} | {int(f(row, 'threads'))} | {f(row, 'assembly_mean', 'assembly_ms'):.3f} | {f(row, 'speedup'):.2f} |")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="绘制 CPU benchmark CSV，输出 PNG/SVG 与中文摘要")
    parser.add_argument("csv", type=Path, nargs="+", help="一个或多个 benchmark CSV")
    parser.add_argument("--out-dir", type=Path, default=Path("results/figures"))
    args = parser.parse_args()

    rows = load_rows(args.csv)
    args.out_dir.mkdir(parents=True, exist_ok=True)

    plot_metric_lines(rows, args.out_dir, "assembly_mean", "装配时间 / ms", "装配时间随线程变化 / Assembly time", "assembly_time")
    plot_metric_lines(rows, args.out_dir, "total_mean", "总时间 / ms", "总时间随线程变化 / Total time", "total_time")
    plot_metric_lines(rows, args.out_dir, "speedup", "加速比", "相对 serial(1) 加速比 / Speedup", "speedup")
    plot_metric_lines(rows, args.out_dir, "efficiency", "并行效率", "并行效率 / Parallel efficiency", "parallel_efficiency")
    plot_preprocess_breakdown(rows, args.out_dir)
    plot_memory(rows, args.out_dir)
    plot_case_comparison(rows, args.out_dir, "cube_vs_windhub", "规则网格 vs 真实风机轮毂网格 / Cube vs WindHub")
    plot_case_comparison([r for r in rows if s(r, "kernel") in {"simplified", "physics_tet4"}], args.out_dir, "simplified_vs_physics_tet4", "简化核 vs 物理 tet4 核 / Simplified vs physics_tet4")
    plot_dashboard(rows, args.out_dir)
    write_summary(rows, args.out_dir)
    print(f"图表和摘要已输出到: {args.out_dir}")


if __name__ == "__main__":
    main()
