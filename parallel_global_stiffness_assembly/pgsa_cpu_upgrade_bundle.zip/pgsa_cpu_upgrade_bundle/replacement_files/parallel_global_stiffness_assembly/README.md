# parallel_global_stiffness_assembly

本目录当前只维护一个主入口：

```text
cpu_parallel_stiffness_assembly/
```

该子项目是 CPU-only / CPU-first 的全局刚度矩阵并行装配 benchmark 平台。默认构建、默认实验和用户可见文档都围绕 CPU OpenMP 算法展开。

历史 CUDA/GPU 内容不再作为主线。如果仍需保留，请放入：

```text
cpu_parallel_stiffness_assembly/legacy_gpu/
```

## 推荐进入方式

```bash
cd cpu_parallel_stiffness_assembly
cmake -S . -B build/cpu-release -DCMAKE_BUILD_TYPE=Release -DPGSA_ENABLE_OPENMP=ON
cmake --build build/cpu-release --parallel
ctest --test-dir build/cpu-release --output-on-failure
```

更详细的 benchmark、实验调度和图表生成说明见 `cpu_parallel_stiffness_assembly/README.md`。
