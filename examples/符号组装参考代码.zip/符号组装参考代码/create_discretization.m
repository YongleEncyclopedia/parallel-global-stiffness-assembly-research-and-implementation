function disc = create_discretization()
% CREATE_DISCRETIZATION  定义每类拓扑点上挂载的自由度数量。
%
% 【对应 PETSc 概念】
% 类比于 PETSc 中的 PetscFE / PetscDS：
% 描述每个拓扑层（顶点 / 边 / 单元）上各挂多少个自由度。
%
% 【第一版设置（CST 线弹性，2D）】
%   顶点：挂 2 个自由度（ux, uy）
%   边  ：挂 0 个自由度
%   单元：挂 0 个自由度
%
% 【扩展说明】
% 如需扩展到高阶单元（如 Serendipity 8 节点单元），只需修改
% dofsPerEdge；如需不连续 Galerkin，修改 dofsPerCell。
% section、closure、cellDofs 的逻辑无需改动，会自动适配。
%
% 输出字段：
%   disc.dim            - 空间维度
%   disc.dofsPerVertex  - 每个顶点点的自由度数
%   disc.dofsPerEdge    - 每条边点的自由度数
%   disc.dofsPerCell    - 每个单元点的自由度数
%   disc.fieldName      - 场名称（人类可读标签）
%   disc.nComp          - 场的分量数

disc.dim           = 2;
disc.dofsPerVertex = 2;   % ux, uy
disc.dofsPerEdge   = 0;   % 预留给高阶单元
disc.dofsPerCell   = 0;   % 预留给泡泡函数 / 非连续模式
disc.fieldName     = 'displacement';
disc.nComp         = 2;

fprintf('[create_discretization] dofsPerVertex=%d  dofsPerEdge=%d  dofsPerCell=%d\n', ...
        disc.dofsPerVertex, disc.dofsPerEdge, disc.dofsPerCell);
end
