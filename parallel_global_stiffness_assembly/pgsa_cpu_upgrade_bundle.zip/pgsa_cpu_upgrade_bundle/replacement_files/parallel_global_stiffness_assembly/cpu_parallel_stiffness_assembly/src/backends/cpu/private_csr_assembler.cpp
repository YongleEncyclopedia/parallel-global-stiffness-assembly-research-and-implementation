#include "backends/cpu/private_csr_assembler.h"

#include <algorithm>
#include <chrono>
#include <sstream>
#include <stdexcept>
#include <vector>

namespace fem::cpu {

namespace {
double ms_since(const std::chrono::steady_clock::time_point t0,
                const std::chrono::steady_clock::time_point t1) {
  return std::chrono::duration<double, std::milli>(t1 - t0).count();
}
} // namespace

PrivateCsrAssembler::PrivateCsrAssembler(AssemblyOptions options) : CpuAssemblerBase(options) {}

void PrivateCsrAssembler::prepare() {
  ensure_ready();

  const auto t0 = std::chrono::steady_clock::now();
  const Size required = static_cast<Size>(threads()) * structure_->nnz() * sizeof(Real);
  if (required > options_.max_transient_bytes) {
    std::ostringstream os;
    os << "cpu_private_csr requires " << memory_string(required)
       << " transient memory, above limit " << memory_string(options_.max_transient_bytes);
    throw std::runtime_error(os.str());
  }

  private_values_.assign(static_cast<Size>(threads()) * structure_->nnz(), 0.0);
  stats_.extra_memory_bytes = required;

  const auto t1 = std::chrono::steady_clock::now();
  stats_.preprocess_time_ms = ms_since(t0, t1);
  stats_.phase_times_ms["alloc_zero"] = stats_.preprocess_time_ms;
}

void PrivateCsrAssembler::assemble() {
  ensure_ready();
  if (private_values_.empty()) prepare();
  reset_result();

  const auto t_all0 = std::chrono::steady_clock::now();

  // 每轮数值装配前必须清零线程私有 CSR values；这部分计入 assembly 子阶段。
  const auto t_zero0 = std::chrono::steady_clock::now();
  std::fill(private_values_.begin(), private_values_.end(), 0.0);
  const auto t_zero1 = std::chrono::steady_clock::now();

  const Size ne = mesh_->num_elements();
  const Size nnz = structure_->nnz();
  const int nth = threads();

  const auto t_elem0 = std::chrono::steady_clock::now();
#ifdef _OPENMP
#pragma omp parallel num_threads(nth)
#endif
  {
    std::vector<Real> ke;
    const int tid = current_thread_id();
    Real* local = private_values_.data() + static_cast<Size>(tid) * nnz;
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
    for (std::int64_t ee = 0; ee < static_cast<std::int64_t>(ne); ++ee) {
      const Size e = static_cast<Size>(ee);
      compute_element_matrix(*mesh_, e, options_, ke);
      const int edofs = plan_->element_dof_count(e);
      const Index* scatter = plan_->element_scatter_ptr(e);
      for (int i = 0; i < edofs; ++i) {
        for (int j = 0; j < edofs; ++j) {
          local[static_cast<Size>(scatter[i * edofs + j])] += ke[static_cast<Size>(i) * edofs + j];
        }
      }
    }
  }
  const auto t_elem1 = std::chrono::steady_clock::now();

  const auto t_reduce0 = std::chrono::steady_clock::now();
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(nth)
#endif
  for (std::int64_t pp = 0; pp < static_cast<std::int64_t>(nnz); ++pp) {
    const Size p = static_cast<Size>(pp);
    Real v = 0.0;
    for (int t = 0; t < nth; ++t) v += private_values_[static_cast<Size>(t) * nnz + p];
    result_.values[p] = v;
  }
  const auto t_reduce1 = std::chrono::steady_clock::now();

  const auto t_all1 = std::chrono::steady_clock::now();
  stats_.phase_times_ms["alloc_zero"] = ms_since(t_zero0, t_zero1);
  stats_.phase_times_ms["element_assemble"] = ms_since(t_elem0, t_elem1);
  stats_.phase_times_ms["nnz_reduce"] = ms_since(t_reduce0, t_reduce1);
  stats_.assembly_time_ms = ms_since(t_all0, t_all1);
  stats_.total_time_ms = stats_.preprocess_time_ms + stats_.assembly_time_ms;
  stats_.diagnostics = "Thread-private CSR arrays followed by deterministic nnz-wise reduction";
}

void PrivateCsrAssembler::cleanup() {
  std::vector<Real>().swap(private_values_);
}

} // namespace fem::cpu
