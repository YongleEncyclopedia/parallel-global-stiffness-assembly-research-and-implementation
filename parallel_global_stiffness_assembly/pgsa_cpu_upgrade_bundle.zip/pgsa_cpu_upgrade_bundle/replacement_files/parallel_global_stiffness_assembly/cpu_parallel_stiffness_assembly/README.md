# CPU Parallel Stiffness Assembly

本目录是仓库当前主线：**CPU 多线程全局刚度矩阵装配 benchmark 平台**。默认构建不要求 CUDA，默认实验围绕 OpenMP CPU 算法展开。

## 已实现 CPU 算法

| 算法 | 一句话说明 |
|---|---|
| `serial` | 单线程正确性与 speedup 基线 |
| `atomic` | 多线程共享 CSR values，写入时使用 OpenMP atomic |
| `private_csr` | 每线程一份 CSR values，最后按 nnz 归约 |
| `coo_sort_reduce` | 线程局部 COO 三元组，合并排序后 reduce 到 CSR |
| `coloring` | 单元图着色，同色无冲突并行装配 |
| `row_owner` | CSR 行 owner-computes，线程只写自己负责的行 |

完整机制、同步方式、预处理成本、内存代价和适用场景见：`docs/cpu/algorithm_overview.md`。

## 构建

```bash
git lfs pull
cmake -S . -B build/cpu-release -DCMAKE_BUILD_TYPE=Release -DPGSA_ENABLE_OPENMP=ON
cmake --build build/cpu-release --parallel
ctest --test-dir build/cpu-release --output-on-failure
```

macOS AppleClang 用户建议先安装 OpenMP：

```bash
brew install cmake libomp git-lfs
git lfs install
```

## Benchmark CLI

```bash
./build/cpu-release/bin/benchmark_assembly --help
```

常用参数：

- `--threads-all`：扫描 `1..max_thread_count()`。
- `--threads-range a:b[:step]`：扫描闭区间线程范围。
- `--threads-list 1,2,4,8,14`：显式线程列表。
- `--case-name <name>`：写入 CSV/JSON/Markdown 的实验名。
- `--json <path>`：输出结构化 JSON。
- `--summary-md <path>`：输出中文 Markdown 摘要。
- `--emit-skip-records`：把 skip 项也写入结果，便于审计。

规则网格示例：

```bash
./build/cpu-release/bin/benchmark_assembly \
  --mesh cube --element tet4 --nx 8 --ny 8 --nz 8 \
  --kernel simplified \
  --algo serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner \
  --threads-range 1:14 \
  --warmup 1 --repeat 3 --check \
  --case-name cube_tet4 \
  --csv results/cube_tet4.csv \
  --json results/cube_tet4.json \
  --summary-md results/cube_tet4.md
```

真实工程网格示例：

```bash
./build/cpu-release/bin/benchmark_assembly \
  --mesh inp --inp examples/3d-WindTurbineHub.inp \
  --kernel simplified \
  --algo serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner \
  --threads-range 1:14 \
  --warmup 1 --repeat 3 --check \
  --case-name windhub \
  --csv results/windhub.csv \
  --json results/windhub.json \
  --summary-md results/windhub.md
```

如果 `.inp` 仍是 Git LFS pointer，benchmark 和实验调度脚本会给出中文错误提示并中止。先运行：

```bash
git lfs install
git lfs pull
```

## 一键实验调度

```bash
python3 scripts/run_cpu_experiments.py --project .
```

默认输出目录：

```text
results/YYYY-MM-DD/<case>/<kernel>/{csv,json,figures,summaries}
```

默认实验计划：

- `cube tet4` / `simplified`：六个算法，线程 `1..14`，`warmup=1 repeat=3`。
- `examples/3d-WindTurbineHub.inp` / `simplified`：六个算法，线程 `1..14`。
- `examples/3d-WindTurbineHub.inp` / `physics_tet4`：`serial/atomic/private_csr/coloring/row_owner` 跑 `1,2,4,8,14`；`coo_sort_reduce` 跑 `1,2,4`。

## 绘图与摘要

```bash
python3 scripts/plot_cpu_results.py results/cube_tet4.csv --out-dir results/figures
```

脚本输出 `PNG + SVG`，并生成中文 `experiment_summary.md`。稳定图表类别包括：

- assembly time
- total time
- speedup
- parallel efficiency
- preprocess breakdown
- extra memory
- cube vs windhub
- simplified vs physics_tet4
- dashboard

CSV 字段保持英文，便于脚本解析；图表、CLI help、终端摘要和 Markdown 摘要为中文优先。

## GPU 历史内容

CUDA/GPU 文件请归档到 `legacy_gpu/`。它们仅作历史参考，不参与默认 CPU 构建和实验。可使用：

```bash
python3 scripts/archive_gpu_legacy.py --project . --dry-run
python3 scripts/archive_gpu_legacy.py --project .
```
