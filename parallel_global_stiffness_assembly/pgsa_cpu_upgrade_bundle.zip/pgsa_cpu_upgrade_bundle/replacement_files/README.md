# Parallel Global Stiffness Assembly Research and Implementation

本仓库当前主线是 **CPU 多线程全局刚度矩阵装配研究与实现**。主入口保持不变：

```text
parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly
```

GPU/CUDA 相关代码如果仍保留在历史树中，应统一迁入 `legacy_gpu/`，仅作为历史参考，不再作为默认开发、构建或实验入口。

## 当前研究范围

- 有限元全局刚度矩阵 CPU 装配；
- OpenMP 并行策略、线程亲和、同步方式和内存占用；
- `serial / atomic / private_csr / coo_sort_reduce / coloring / row_owner` 六类 CPU 算法；
- 规则网格与真实工程网格的 strong-scaling benchmark；
- CSV/JSON/Markdown 结果归档与中文实验图表。

## 快速入口

```bash
cd parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly
cmake -S . -B build/cpu-release -DCMAKE_BUILD_TYPE=Release -DPGSA_ENABLE_OPENMP=ON
cmake --build build/cpu-release --parallel
ctest --test-dir build/cpu-release --output-on-failure
```

运行一个规则网格 benchmark：

```bash
./build/cpu-release/bin/benchmark_assembly \
  --mesh cube --element tet4 --nx 8 --ny 8 --nz 8 \
  --kernel simplified \
  --algo serial,atomic,private_csr,coo_sort_reduce,coloring,row_owner \
  --threads-range 1:14 \
  --warmup 1 --repeat 3 --check \
  --case-name cube_tet4 \
  --csv results/cube_tet4.csv \
  --json results/cube_tet4.json \
  --summary-md results/cube_tet4.md
```

## 文档

- CPU 子项目说明：`parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly/README.md`
- CPU 算法总览：`parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly/docs/cpu/algorithm_overview.md`
- GPU 历史归档说明：`parallel_global_stiffness_assembly/cpu_parallel_stiffness_assembly/legacy_gpu/README.md`

## 研究依据

本项目文档统一引用 OpenMP 官方规范、CMake 官方 `FindOpenMP` 文档，以及 Krysl 2024 multicore finite element assembly benchmark 论文。详细说明见 CPU 算法总览文档。
