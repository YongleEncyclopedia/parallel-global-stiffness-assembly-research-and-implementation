function cellDofs = build_cell_dofs(cellIdx, topo, section)
% BUILD_CELL_DOFS  通过 closure + section 推导单元的全局自由度编号列表。
%
% 【对应 PETSc 概念】
% 类比于 PETSc 中的 DMPlexGetClosureIndices()。
%
% 【核心逻辑链（PETSc 思想的精髓）】
%   单元 c
%    └─► get_cell_closure(c)       → 闭包中的全部点
%         └─► 遍历每个点 p：
%              section.ndof(p)    → 该点挂载的自由度数
%              section.offset(p)  → 该点在全局向量中的起始偏移
%               └─► 全局 DOF 下标：offset(p)+1 .. offset(p)+ndof(p)
%                    └─► 追加到 cellDofs
%
% 【重要】ndof == 0 的点（本版本中的边和单元点）会被自动跳过，
%         因此本函数对未来扩展（边/单元挂自由度）无需修改。
%
% 输入：
%   cellIdx  - 单元局部编号（1 .. nCell）
%   topo     - 网格拓扑结构体
%   section  - section 结构体（来自 build_section）
%
% 输出：
%   cellDofs - (nLocalDof x 1) 全局自由度下标列向量（1-based，MATLAB 惯例）

% 第一步：获取拓扑闭包（纯拓扑操作，不涉及坐标或刚度）
closurePoints = get_cell_closure(cellIdx, topo);

% 第二步：遍历闭包点，通过 section 收集全局 DOF 下标
cellDofs = [];
for k = 1 : length(closurePoints)
    p  = closurePoints(k);
    nd = section.ndof(p);
    if nd > 0
        off      = section.offset(p);          % 0-based 偏移
        newDofs  = (off + 1 : off + nd)';      % 转为 1-based MATLAB 下标
        cellDofs = [cellDofs; newDofs];         %#ok<AGROW>
    end
end
end
