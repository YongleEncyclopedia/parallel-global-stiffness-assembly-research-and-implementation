# CSC3 对称稀疏组装 Demo Windows x64 交付

本包面向研究院接收方，包含可独立构建的源码 ZIP、中文测试报告、Windows 原始性能证据、MSVC/MinGW/CTest/consumer/clean-room 日志、内部评估和逐文件 SHA-256。

## 快速入口

- 源码：`01_源代码/csc3_symmetric_assembly_demo_source.zip`
- 中文报告：`02_测试报告/测试报告.md`
- 原始性能 CSV：`03_性能原始证据/benchmark_samples.csv`
- 性能汇总与进程 manifest：`03_性能原始证据/benchmark_summary.json`、`03_性能原始证据/run_manifest.json`
- 构建证据：`04_构建与CleanRoom证据/build_evidence.json`
- 内部评估：`05_内部评估/内部评估.md`
- 校验和：`06_校验/SHA256SUMS.txt`

## 校验

源码 ZIP SHA-256：`030ce28325d4ad99eb421b8343065c6e44d1e63a31699c9d70924e9826e728d2`

WindHub 输入：`examples/3d-WindTurbineHub.inp`<br>
输入大小：`76111745 bytes`
输入 SHA-256：`4f3066b7e388ff0abaccb41d9ff5ec5a668e8d6ed008ae0c1061951f836ae0c3`

使用任意 SHA-256 工具核对 `06_校验/SHA256SUMS.txt`。外层 ZIP 自身的 SHA-256 位于同目录的 `.sha256` 侧车文件；该侧车文件不在 ZIP 内，避免自引用。

## 构建边界

源码 ZIP 不包含 WindHub 大型 Git LFS 实体、构建目录、编译产物、缓存或宿主绝对路径。CTest 与最小 consumer 不依赖 WindHub 输入；如需复现实测，须从仓库 Git LFS 取得与上述 SHA-256 一致的实体文件。
